from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal
from products.models import Category, Brand, Product
from cart.models import Cart, CartItem

class CartTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='cart_user', password='password123')
        self.client.login(username='cart_user', password='password123')

        self.category = Category.objects.create(name='Audio')
        self.brand = Brand.objects.create(name='Sony')
        self.product = Product.objects.create(
            category=self.category,
            brand=self.brand,
            name='Sony Headphones',
            description='Noise cancelling',
            specifications='Battery: 30hrs',
            price=Decimal('200.00'),
            discount_percentage=10, # discounted = 180.00
            stock=3
        )

    def test_add_to_cart_and_totals(self):
        # Add 2 items
        response = self.client.post(reverse('add_to_cart', kwargs={'product_id': self.product.id}), {'quantity': 2})
        self.assertEqual(response.status_code, 302)

        cart = Cart.objects.get(user=self.user)
        self.assertEqual(cart.get_total_items(), 2)
        self.assertEqual(cart.get_subtotal(), Decimal('400.00'))
        self.assertEqual(cart.get_discounted_subtotal(), Decimal('360.00'))
        self.assertEqual(cart.get_shipping_charge(), Decimal('0.00')) # Over ₹99 -> free shipping
        self.assertEqual(cart.get_grand_total(), Decimal('360.00'))

    def test_stock_limitation_in_cart(self):
        # Request 10 items when stock is only 3
        response = self.client.post(reverse('add_to_cart', kwargs={'product_id': self.product.id}), {'quantity': 10})
        self.assertEqual(response.status_code, 302)

        cart = Cart.objects.get(user=self.user)
        cart_item = cart.items.get(product=self.product)
        self.assertEqual(cart_item.quantity, 3) # capped at stock
