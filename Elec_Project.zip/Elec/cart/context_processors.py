from cart.models import Cart
from wishlist.models import Wishlist
from products.models import Category

def cart_and_wishlist_counters(request):
    cart_count = 0
    wishlist_count = 0
    categories = Category.objects.all().order_by('name')

    if request.user.is_authenticated:
        try:
            cart = Cart.objects.filter(user=request.user).first()
            if cart:
                cart_count = cart.get_total_items()
        except Exception:
            cart_count = 0

        try:
            wishlist_count = Wishlist.objects.filter(user=request.user).count()
        except Exception:
            wishlist_count = 0

    return {
        'cart_count': cart_count,
        'wishlist_count': wishlist_count,
        'nav_categories': categories,
    }
