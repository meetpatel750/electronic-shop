from django.db import models
from django.contrib.auth.models import User
from products.models import Product
from decimal import Decimal

class Cart(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='cart')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Cart of {self.user.username}"

    def get_subtotal(self):
        return sum(item.get_total_price() for item in self.items.all())

    def get_discounted_subtotal(self):
        return sum(item.get_discounted_total() for item in self.items.all())

    def get_total_discount(self):
        return self.get_subtotal() - self.get_discounted_subtotal()

    def get_shipping_charge(self):
        discounted_subtotal = self.get_discounted_subtotal()
        if discounted_subtotal == Decimal('0.00') or self.items.count() == 0:
            return Decimal('0.00')
        if discounted_subtotal >= Decimal('499.00'):
            return Decimal('0.00')  # Free shipping over ₹499
        return Decimal('99.00')

    def get_grand_total(self):
        return self.get_discounted_subtotal() + self.get_shipping_charge()

    def get_total_items(self):
        return sum(item.quantity for item in self.items.all())


class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ('cart', 'product')

    def __str__(self):
        return f"{self.quantity} x {self.product.name}"

    def get_total_price(self):
        return self.product.price * self.quantity

    def get_discounted_total(self):
        return self.product.discounted_price * self.quantity

    def get_discount_amount(self):
        return (self.product.price - self.product.discounted_price) * self.quantity
