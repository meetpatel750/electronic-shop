from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from products.models import Product
from .models import Cart, CartItem

@login_required
def cart_detail_view(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)
    items = cart.items.select_related('product', 'product__brand', 'product__category').all()
    
    context = {
        'cart': cart,
        'items': items,
        'subtotal': cart.get_subtotal(),
        'discounted_subtotal': cart.get_discounted_subtotal(),
        'total_discount': cart.get_total_discount(),
        'shipping_charge': cart.get_shipping_charge(),
        'grand_total': cart.get_grand_total(),
        'total_items': cart.get_total_items(),
    }
    return render(request, 'cart/cart_detail.html', context)


@login_required
def add_to_cart_view(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_active=True)
    is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json'

    if product.stock <= 0:
        msg = f"Sorry, '{product.name}' is currently out of stock."
        if is_ajax:
            return JsonResponse({'status': 'error', 'message': msg}, status=400)
        messages.error(request, msg)
        return redirect(request.META.get('HTTP_REFERER', 'product_list'))

    try:
        qty = int(request.POST.get('quantity', 1))
    except (ValueError, TypeError):
        qty = 1

    if qty < 1:
        qty = 1

    cart, _ = Cart.objects.get_or_create(user=request.user)
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)

    if not created:
        new_qty = cart_item.quantity + qty
        if new_qty > product.stock:
            cart_item.quantity = product.stock
            cart_item.save()
            msg = f"Adjusted quantity to maximum available stock ({product.stock}) for '{product.name}'."
            messages.warning(request, msg)
        else:
            cart_item.quantity = new_qty
            cart_item.save()
            msg = f"Updated quantity for '{product.name}' in your cart."
            messages.success(request, msg)
    else:
        if qty > product.stock:
            cart_item.quantity = product.stock
            msg = f"Added maximum available stock ({product.stock}) of '{product.name}' to your cart."
        else:
            cart_item.quantity = qty
            msg = f"'{product.name}' has been added to your cart!"
        cart_item.save()
        messages.success(request, msg)

    # If buy now clicked, redirect directly to checkout
    if request.POST.get('buy_now'):
        return redirect('checkout')

    if is_ajax:
        return JsonResponse({
            'status': 'success',
            'message': msg,
            'cart_count': cart.get_total_items(),
            'product_name': product.name,
        })

    return redirect(request.META.get('HTTP_REFERER', 'cart_detail'))


@login_required
def update_cart_item_view(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json'
    
    action = request.POST.get('action')
    try:
        requested_qty = int(request.POST.get('quantity', cart_item.quantity))
    except (ValueError, TypeError):
        requested_qty = cart_item.quantity

    if action == 'increase':
        new_qty = cart_item.quantity + 1
    elif action == 'decrease':
        new_qty = cart_item.quantity - 1
    else:
        new_qty = requested_qty

    cart = cart_item.cart

    if new_qty <= 0:
        product_name = cart_item.product.name
        cart_item.delete()
        msg = f"Removed '{product_name}' from your cart."
        messages.info(request, msg)
        if is_ajax:
            return JsonResponse({
                'status': 'removed',
                'message': msg,
                'cart_count': cart.get_total_items(),
                'subtotal': float(cart.get_subtotal()),
                'discounted_subtotal': float(cart.get_discounted_subtotal()),
                'total_discount': float(cart.get_total_discount()),
                'shipping_charge': float(cart.get_shipping_charge()),
                'grand_total': float(cart.get_grand_total()),
            })
        return redirect('cart_detail')

    if new_qty > cart_item.product.stock:
        cart_item.quantity = cart_item.product.stock
        cart_item.save()
        msg = f"Cannot add more than {cart_item.product.stock} items of '{cart_item.product.name}'."
        messages.warning(request, msg)
    else:
        cart_item.quantity = new_qty
        cart_item.save()
        msg = f"Cart updated."

    if is_ajax:
        return JsonResponse({
            'status': 'success',
            'message': msg,
            'quantity': cart_item.quantity,
            'item_total': float(cart_item.get_discounted_total()),
            'cart_count': cart.get_total_items(),
            'subtotal': float(cart.get_subtotal()),
            'discounted_subtotal': float(cart.get_discounted_subtotal()),
            'total_discount': float(cart.get_total_discount()),
            'shipping_charge': float(cart.get_shipping_charge()),
            'grand_total': float(cart.get_grand_total()),
        })

    return redirect('cart_detail')


@login_required
def remove_from_cart_view(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    product_name = cart_item.product.name
    cart = cart_item.cart
    cart_item.delete()
    
    msg = f"'{product_name}' was removed from your cart."
    messages.success(request, msg)
    
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json':
        return JsonResponse({
            'status': 'success',
            'message': msg,
            'cart_count': cart.get_total_items(),
            'subtotal': float(cart.get_subtotal()),
            'discounted_subtotal': float(cart.get_discounted_subtotal()),
            'total_discount': float(cart.get_total_discount()),
            'shipping_charge': float(cart.get_shipping_charge()),
            'grand_total': float(cart.get_grand_total()),
        })

    return redirect('cart_detail')


@login_required
def clear_cart_view(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)
    cart.items.all().delete()
    messages.info(request, "Your cart has been cleared.")
    return redirect('cart_detail')
