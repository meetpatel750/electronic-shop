from django.urls import path
from . import views

urlpatterns = [
    path('', views.admin_dashboard_view, name='admin_dashboard'),
    path('login/', views.admin_login_view, name='admin_login'),
    path('logout/', views.admin_logout_view, name='admin_logout'),
    
    # Products
    path('products/', views.admin_product_list_view, name='admin_product_list'),
    path('products/add/', views.admin_product_add_view, name='admin_product_add'),
    path('products/<int:pk>/edit/', views.admin_product_edit_view, name='admin_product_edit'),
    path('products/<int:pk>/delete/', views.admin_product_delete_view, name='admin_product_delete'),
    
    # Categories
    path('categories/', views.admin_category_list_view, name='admin_category_list'),
    path('categories/<int:pk>/delete/', views.admin_category_delete_view, name='admin_category_delete'),

    # Brands
    path('brands/', views.admin_brand_list_view, name='admin_brand_list'),
    path('brands/<int:pk>/delete/', views.admin_brand_delete_view, name='admin_brand_delete'),

    # Orders
    path('orders/', views.admin_order_list_view, name='admin_order_list'),
    path('orders/<int:pk>/', views.admin_order_detail_view, name='admin_order_detail'),

    # Reviews
    path('reviews/', views.admin_review_list_view, name='admin_review_list'),
    path('reviews/<int:pk>/delete/', views.admin_review_delete_view, name='admin_review_delete'),

    # Users
    path('users/', views.admin_user_list_view, name='admin_user_list'),
]
