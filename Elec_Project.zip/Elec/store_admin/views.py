from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from django.db.models import Sum, Count
from decimal import Decimal
import json

from products.models import Product, Category, Brand, ProductImage
from orders.models import Order, OrderItem
from reviews.models import Review
from .forms import AdminProductForm, AdminCategoryForm, AdminBrandForm, AdminOrderStatusForm
from accounts.forms import LoginForm

def staff_required(view_func):
    return user_passes_test(lambda u: u.is_authenticated and u.is_staff, login_url='admin_login')(view_func)

def admin_login_view(request):
    if request.user.is_authenticated:
        if request.user.is_staff:
            return redirect('admin_dashboard')
        else:
            messages.warning(request, "Your current account does not have staff privileges.")

    next_url = request.GET.get('next', 'admin_dashboard')

    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username_or_email = form.cleaned_data['username']
            password = form.cleaned_data['password']

            user = None
            if '@' in username_or_email:
                user_obj = User.objects.filter(email=username_or_email).first()
                if user_obj:
                    user = authenticate(request, username=user_obj.username, password=password)
            else:
                user = authenticate(request, username=username_or_email, password=password)

            if user is not None:
                if user.is_staff:
                    login(request, user)
                    messages.success(request, f"Welcome to Control Center, {user.first_name or user.username}!")
                    return redirect(request.POST.get('next') or next_url)
                else:
                    messages.error(request, "Access Denied: You do not have administrator or staff permissions.")
            else:
                messages.error(request, "Invalid administrator credentials. Please check username and password.")
    else:
        form = LoginForm()

    return render(request, 'store_admin/admin_login.html', {'form': form, 'next': next_url})


def admin_logout_view(request):
    logout(request)
    messages.info(request, "Administrator logged out successfully.")
    return redirect('admin_login')


@staff_required
def admin_dashboard_view(request):
    total_users = User.objects.filter(is_staff=False).count()
    total_products = Product.objects.count()
    total_categories = Category.objects.count()
    total_orders = Order.objects.count()
    pending_orders = Order.objects.filter(order_status='Pending').count()
    delivered_orders = Order.objects.filter(order_status='Delivered').count()
    
    # Calculate total revenue from valid orders (non-cancelled)
    total_sales = Order.objects.exclude(order_status='Cancelled').aggregate(Sum('total_amount'))['total_amount__sum'] or Decimal('0.00')

    # Status distribution for charts
    status_counts = []
    status_labels = [s[0] for s in Order.ORDER_STATUS_CHOICES]
    for st in status_labels:
        status_counts.append(Order.objects.filter(order_status=st).count())

    # Category distribution for charts
    categories = Category.objects.annotate(p_count=Count('products'))
    cat_labels = [c.name for c in categories]
    cat_counts = [c.p_count for c in categories]

    recent_orders = Order.objects.select_related('user').order_by('-created_at')[:6]
    recent_reviews = Review.objects.select_related('user', 'product').order_by('-created_at')[:6]

    context = {
        'total_users': total_users,
        'total_products': total_products,
        'total_categories': total_categories,
        'total_orders': total_orders,
        'pending_orders': pending_orders,
        'delivered_orders': delivered_orders,
        'total_sales': total_sales,
        'recent_orders': recent_orders,
        'recent_reviews': recent_reviews,
        'status_labels_json': json.dumps(status_labels),
        'status_counts_json': json.dumps(status_counts),
        'cat_labels_json': json.dumps(cat_labels),
        'cat_counts_json': json.dumps(cat_counts),
    }
    return render(request, 'store_admin/dashboard.html', context)


# ==================== PRODUCT MANAGEMENT ====================

@staff_required
def admin_product_list_view(request):
    products = Product.objects.select_related('category', 'brand').order_by('-created_at')
    
    search = request.GET.get('search', '').strip()
    if search:
        products = products.filter(name__icontains=search)

    cat_id = request.GET.get('category')
    if cat_id:
        products = products.filter(category_id=cat_id)

    categories = Category.objects.all()
    return render(request, 'store_admin/products_list.html', {
        'products': products,
        'categories': categories,
        'search': search,
        'selected_cat': cat_id,
    })


@staff_required
def admin_product_add_view(request):
    if request.method == 'POST':
        form = AdminProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save()
            
            # Handle additional gallery images if uploaded
            images = request.FILES.getlist('additional_images')
            for img in images:
                ProductImage.objects.create(product=product, image=img)

            messages.success(request, f"Product '{product.name}' created successfully!")
            return redirect('admin_product_list')
        else:
            messages.error(request, "Failed to create product. Check form errors.")
    else:
        form = AdminProductForm()

    return render(request, 'store_admin/product_form.html', {'form': form, 'title': 'Add New Product'})


@staff_required
def admin_product_edit_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = AdminProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            images = request.FILES.getlist('additional_images')
            for img in images:
                ProductImage.objects.create(product=product, image=img)
            messages.success(request, f"Product '{product.name}' updated successfully!")
            return redirect('admin_product_list')
        else:
            messages.error(request, "Failed to update product.")
    else:
        form = AdminProductForm(instance=product)

    return render(request, 'store_admin/product_form.html', {
        'form': form,
        'product': product,
        'title': f"Edit Product: {product.name}",
    })


@staff_required
def admin_product_delete_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        name = product.name
        product.delete()
        messages.success(request, f"Product '{name}' deleted successfully.")
    return redirect('admin_product_list')


# ==================== CATEGORY & BRAND MANAGEMENT ====================

@staff_required
def admin_category_list_view(request):
    categories = Category.objects.annotate(p_count=Count('products')).order_by('name')
    if request.method == 'POST':
        form = AdminCategoryForm(request.POST, request.FILES)
        if form.is_valid():
            cat = form.save()
            messages.success(request, f"Category '{cat.name}' added successfully!")
            return redirect('admin_category_list')
    else:
        form = AdminCategoryForm()

    return render(request, 'store_admin/categories_list.html', {'categories': categories, 'form': form})


@staff_required
def admin_category_delete_view(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        name = category.name
        category.delete()
        messages.success(request, f"Category '{name}' deleted.")
    return redirect('admin_category_list')


@staff_required
def admin_brand_list_view(request):
    brands = Brand.objects.annotate(p_count=Count('products')).order_by('name')
    if request.method == 'POST':
        form = AdminBrandForm(request.POST, request.FILES)
        if form.is_valid():
            brand = form.save()
            messages.success(request, f"Brand '{brand.name}' added successfully!")
            return redirect('admin_brand_list')
    else:
        form = AdminBrandForm()

    return render(request, 'store_admin/brands_list.html', {'brands': brands, 'form': form})


@staff_required
def admin_brand_delete_view(request, pk):
    brand = get_object_or_404(Brand, pk=pk)
    if request.method == 'POST':
        name = brand.name
        brand.delete()
        messages.success(request, f"Brand '{name}' deleted.")
    return redirect('admin_brand_list')


# ==================== ORDER MANAGEMENT ====================

@staff_required
def admin_order_list_view(request):
    orders = Order.objects.select_related('user').order_by('-created_at')

    status = request.GET.get('status')
    if status:
        orders = orders.filter(order_status=status)

    search = request.GET.get('search', '').strip()
    if search:
        orders = orders.filter(order_number__icontains=search)

    return render(request, 'store_admin/orders_list.html', {
        'orders': orders,
        'status_choices': Order.ORDER_STATUS_CHOICES,
        'selected_status': status,
        'search': search,
    })


@staff_required
def admin_order_detail_view(request, pk):
    order = get_object_or_404(Order.objects.prefetch_related('items', 'items__product'), pk=pk)

    if request.method == 'POST':
        form = AdminOrderStatusForm(request.POST, instance=order)
        if form.is_valid():
            old_status = order.order_status
            updated_order = form.save()
            
            # If changed to cancelled from confirmed, restore stock
            if old_status in ['Pending', 'Confirmed', 'Processing'] and updated_order.order_status == 'Cancelled':
                for item in updated_order.items.all():
                    if item.product:
                        Product.objects.filter(pk=item.product.pk).update(stock=item.product.stock + item.quantity)
            
            messages.success(request, f"Order #{order.order_number} status updated successfully!")
            return redirect('admin_order_detail', pk=order.pk)
    else:
        form = AdminOrderStatusForm(instance=order)

    return render(request, 'store_admin/order_detail.html', {'order': order, 'form': form})


# ==================== REVIEW MODERATION & USER LIST ====================

@staff_required
def admin_review_list_view(request):
    reviews = Review.objects.select_related('user', 'product').order_by('-created_at')
    return render(request, 'store_admin/reviews_list.html', {'reviews': reviews})


@staff_required
def admin_review_delete_view(request, pk):
    review = get_object_or_404(Review, pk=pk)
    if request.method == 'POST':
        review.delete()
        messages.success(request, "Review deleted by admin.")
    return redirect('admin_review_list')


@staff_required
def admin_user_list_view(request):
    users = User.objects.annotate(order_count=Count('orders')).order_by('-date_joined')
    return render(request, 'store_admin/users_list.html', {'users': users})
