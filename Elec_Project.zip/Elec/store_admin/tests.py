from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal
from products.models import Category, Brand, Product

class AdminDashboardTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.staff_user = User.objects.create_user(username='staff_admin', password='password123', is_staff=True)
        self.regular_user = User.objects.create_user(username='regular_customer', password='password123', is_staff=False)

    def test_staff_access_only(self):
        # Anonymous should redirect to login
        res_anon = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(res_anon.status_code, 302)

        # Regular user should redirect
        self.client.login(username='regular_customer', password='password123')
        res_reg = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(res_reg.status_code, 302)

        # Staff user should get 200
        self.client.login(username='staff_admin', password='password123')
        res_staff = self.client.get(reverse('admin_dashboard'))
        self.assertEqual(res_staff.status_code, 200)
        self.assertContains(res_staff, 'Store Admin Dashboard')
