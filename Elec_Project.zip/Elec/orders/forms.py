from django import forms
from .models import Order
from accounts.models import Address

class CheckoutForm(forms.Form):
    PAYMENT_CHOICES = [
        ('Cash on Delivery', 'Cash on Delivery (COD)'),
        ('Online Payment', 'Online Payment (Debit/Credit Card, UPI, Net Banking)'),
    ]

    selected_address = forms.ModelChoiceField(
        queryset=Address.objects.none(),
        required=False,
        empty_label="-- Select a Saved Address --",
        widget=forms.Select(attrs={'class': 'form-select mb-3', 'id': 'saved-address-select'})
    )

    # Fields for a new address if no saved address chosen
    full_name = forms.CharField(max_length=150, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}))
    phone = forms.CharField(max_length=20, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Phone Number'}))
    address_line = forms.CharField(max_length=255, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Street Address, Apartment, Suite'}))
    city = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'City'}))
    state = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'State / Province'}))
    pincode = forms.CharField(max_length=20, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Postal Code / ZIP'}))
    country = forms.CharField(max_length=100, required=False, initial='United States', widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Country'}))
    save_to_address_book = forms.BooleanField(required=False, initial=True, widget=forms.CheckboxInput(attrs={'class': 'form-check-input'}))

    payment_method = forms.ChoiceField(
        choices=PAYMENT_CHOICES,
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'})
    )

    def __init__(self, user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if user and user.is_authenticated:
            self.fields['selected_address'].queryset = Address.objects.filter(user=user)
            default_addr = Address.objects.filter(user=user, is_default=True).first()
            if default_addr:
                self.fields['selected_address'].initial = default_addr

    def clean(self):
        cleaned_data = super().clean()
        selected_address = cleaned_data.get('selected_address')
        
        if not selected_address:
            # Must provide manual address fields
            required_fields = ['full_name', 'phone', 'address_line', 'city', 'state', 'pincode']
            for field in required_fields:
                if not cleaned_data.get(field):
                    self.add_error(field, f"{field.replace('_', ' ').title()} is required if no saved address is selected.")
        return cleaned_data
