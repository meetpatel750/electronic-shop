from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from cart.models import Cart, CartItem
from accounts.models import Address
from products.models import Product
from .models import Order, OrderItem
from .forms import CheckoutForm

@login_required
def checkout_view(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)
    cart_items = cart.items.select_related('product').all()

    if not cart_items.exists():
        messages.warning(request, "Your cart is empty. Add products before checking out.")
        return redirect('cart_detail')

    # Validate stock before proceeding
    for item in cart_items:
        if item.quantity > item.product.stock:
            messages.error(request, f"Item '{item.product.name}' only has {item.product.stock} units available.")
            return redirect('cart_detail')

    saved_addresses = Address.objects.filter(user=request.user)

    if request.method == 'POST':
        form = CheckoutForm(request.user, request.POST)
        if form.is_valid():
            selected_address = form.cleaned_data.get('selected_address')
            payment_method = form.cleaned_data.get('payment_method')
            
            # Handle address
            shipping_address_obj = None
            if selected_address:
                shipping_address_obj = selected_address
                address_text = f"{selected_address.full_name}, Phone: {selected_address.phone}, {selected_address.address_line}, {selected_address.city}, {selected_address.state} - {selected_address.pincode}, {selected_address.country}"
            else:
                full_name = form.cleaned_data.get('full_name')
                phone = form.cleaned_data.get('phone')
                address_line = form.cleaned_data.get('address_line')
                city = form.cleaned_data.get('city')
                state = form.cleaned_data.get('state')
                pincode = form.cleaned_data.get('pincode')
                country = form.cleaned_data.get('country') or 'United States'
                
                address_text = f"{full_name}, Phone: {phone}, {address_line}, {city}, {state} - {pincode}, {country}"

                if form.cleaned_data.get('save_to_address_book'):
                    is_first = not Address.objects.filter(user=request.user).exists()
                    shipping_address_obj = Address.objects.create(
                        user=request.user,
                        full_name=full_name,
                        phone=phone,
                        address_line=address_line,
                        city=city,
                        state=state,
                        pincode=pincode,
                        country=country,
                        is_default=is_first
                    )

            # Create Order inside atomic transaction
            with transaction.atomic():
                subtotal = cart.get_subtotal()
                discount = cart.get_total_discount()
                shipping = cart.get_shipping_charge()
                total = cart.get_grand_total()

                order = Order.objects.create(
                    user=request.user,
                    address=shipping_address_obj,
                    shipping_address_text=address_text,
                    subtotal=subtotal,
                    discount=discount,
                    shipping_charge=shipping,
                    total_amount=total,
                    payment_method=payment_method,
                    payment_status='COD' if payment_method == 'Cash on Delivery' else 'Pending',
                    order_status='Confirmed' if payment_method == 'Cash on Delivery' else 'Pending',
                )

                # Create OrderItems
                for item in cart_items:
                    OrderItem.objects.create(
                        order=order,
                        product=item.product,
                        product_name=item.product.name,
                        price=item.product.discounted_price,
                        quantity=item.quantity,
                        total=item.get_discounted_total()
                    )

                if payment_method == 'Cash on Delivery':
                    # Deduct stock immediately for COD
                    for item in cart_items:
                        Product.objects.filter(pk=item.product.pk).update(stock=item.product.stock - item.quantity)
                    
                    # Clear cart
                    cart.items.all().delete()
                    messages.success(request, f"Order #{order.order_number} has been placed successfully!")
                    return redirect('order_success', order_number=order.order_number)
                else:
                    # Online Payment flow
                    return redirect('mock_online_payment', order_number=order.order_number)
        else:
            messages.error(request, "Please fill in all required shipping and payment details.")
    else:
        form = CheckoutForm(request.user)

    context = {
        'form': form,
        'cart': cart,
        'cart_items': cart_items,
        'saved_addresses': saved_addresses,
        'subtotal': cart.get_subtotal(),
        'discounted_subtotal': cart.get_discounted_subtotal(),
        'total_discount': cart.get_total_discount(),
        'shipping_charge': cart.get_shipping_charge(),
        'grand_total': cart.get_grand_total(),
    }
    return render(request, 'orders/checkout.html', context)


@login_required
def mock_online_payment_view(request, order_number):
    order = get_object_or_404(Order, order_number=order_number, user=request.user)

    if order.payment_status == 'Paid':
        messages.info(request, "This order has already been paid.")
        return redirect('order_success', order_number=order.order_number)

    if request.method == 'POST':
        action = request.POST.get('payment_action', 'success')
        
        if action == 'success':
            with transaction.atomic():
                order.payment_status = 'Paid'
                order.order_status = 'Confirmed'
                order.save()

                # Deduct stock for all order items
                for item in order.items.all():
                    if item.product:
                        Product.objects.filter(pk=item.product.pk).update(stock=item.product.stock - item.quantity)

                # Clear user's cart
                cart = Cart.objects.filter(user=request.user).first()
                if cart:
                    cart.items.all().delete()

            messages.success(request, f"Payment successful! Order #{order.order_number} confirmed.")
            return redirect('order_success', order_number=order.order_number)
        else:
            order.payment_status = 'Failed'
            order.save()
            messages.error(request, "Payment failed or was cancelled. You may retry payment below.")

    return render(request, 'orders/payment_online.html', {'order': order})


@login_required
def order_success_view(request, order_number):
    order = get_object_or_404(Order.objects.prefetch_related('items'), order_number=order_number, user=request.user)
    return render(request, 'orders/order_success.html', {'order': order})


@login_required
def my_orders_view(request):
    orders_list = Order.objects.filter(user=request.user).prefetch_related('items').order_by('-created_at')
    
    status_filter = request.GET.get('status', '').strip()
    if status_filter:
        orders_list = orders_list.filter(order_status=status_filter)

    return render(request, 'orders/order_list.html', {
        'orders': orders_list,
        'status_filter': status_filter,
        'status_choices': Order.ORDER_STATUS_CHOICES,
    })


@login_required
def order_detail_view(request, order_number):
    order = get_object_or_404(Order.objects.prefetch_related('items', 'items__product'), order_number=order_number, user=request.user)
    return render(request, 'orders/order_detail.html', {'order': order})


@login_required
def cancel_order_view(request, order_number):
    order = get_object_or_404(Order, order_number=order_number, user=request.user)

    if not order.can_cancel:
        messages.error(request, f"Order #{order.order_number} cannot be cancelled because it is in '{order.order_status}' status.")
        return redirect('order_detail', order_number=order.order_number)

    if request.method == 'POST':
        with transaction.atomic():
            # Restore stock if stock was decremented
            if order.order_status in ['Confirmed', 'Processing']:
                for item in order.items.all():
                    if item.product:
                        Product.objects.filter(pk=item.product.pk).update(stock=item.product.stock + item.quantity)
            
            order.order_status = 'Cancelled'
            order.save()
            messages.success(request, f"Order #{order.order_number} has been cancelled successfully.")

    return redirect('order_detail', order_number=order.order_number)


@login_required
def invoice_view(request, order_number):
    order = get_object_or_404(Order.objects.prefetch_related('items'), order_number=order_number, user=request.user)
    return render(request, 'orders/invoice.html', {'order': order})
