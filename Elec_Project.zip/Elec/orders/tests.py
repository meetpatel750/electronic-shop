from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal
from products.models import Category, Brand, Product
from accounts.models import Address
from cart.models import Cart, CartItem
from orders.models import Order

class OrdersTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='order_user', password='password123')
        self.client.login(username='order_user', password='password123')

        self.address = Address.objects.create(
            user=self.user,
            full_name='Test Buyer',
            phone='1234567890',
            address_line='456 Elm St',
            city='Dallas',
            state='TX',
            pincode='75001',
            country='United States',
            is_default=True
        )

        self.category = Category.objects.create(name='Laptops')
        self.brand = Brand.objects.create(name='Dell')
        self.product = Product.objects.create(
            category=self.category,
            brand=self.brand,
            name='Dell XPS 15',
            description='Power laptop',
            specifications='RAM: 32GB',
            price=Decimal('1500.00'),
            stock=10
        )

        self.cart, _ = Cart.objects.get_or_create(user=self.user)
        CartItem.objects.create(cart=self.cart, product=self.product, quantity=2)

    def test_checkout_and_stock_deduction(self):
        initial_stock = self.product.stock
        response = self.client.post(reverse('checkout'), {
            'selected_address': self.address.id,
            'payment_method': 'Cash on Delivery'
        })
        self.assertEqual(response.status_code, 302)

        order = Order.objects.filter(user=self.user).first()
        self.assertIsNotNone(order)
        self.assertEqual(order.order_status, 'Confirmed')
        self.assertEqual(order.payment_status, 'COD')
        self.assertEqual(order.items.count(), 1)
        self.assertEqual(order.total_amount, Decimal('3000.00'))

        # Stock should be decremented by 2
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, initial_stock - 2)

        # Cart should be empty
        self.assertEqual(self.cart.items.count(), 0)

        # Order Cancellation test (allowed for Confirmed status)
        self.assertTrue(order.can_cancel)
        cancel_response = self.client.post(reverse('cancel_order', kwargs={'order_number': order.order_number}))
        self.assertEqual(cancel_response.status_code, 302)
        order.refresh_from_db()
        self.assertEqual(order.order_status, 'Cancelled')

        # Stock should be restored
        self.product.refresh_from_db()
        self.assertEqual(self.product.stock, initial_stock)
