from django.urls import path
from . import views

urlpatterns = [
    path('checkout/', views.checkout_view, name='checkout'),
    path('pay/<str:order_number>/', views.mock_online_payment_view, name='mock_online_payment'),
    path('success/<str:order_number>/', views.order_success_view, name='order_success'),
    path('orders/', views.my_orders_view, name='my_orders'),
    path('orders/<str:order_number>/', views.order_detail_view, name='order_detail'),
    path('orders/<str:order_number>/cancel/', views.cancel_order_view, name='cancel_order'),
    path('orders/<str:order_number>/invoice/', views.invoice_view, name='invoice_view'),
]
