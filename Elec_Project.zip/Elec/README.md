# ⚡ Online Electronic Product Selling System (ElectroShop)

A complete, production-ready full-stack Django e-commerce web application designed for selling high-end electronic products (smartphones, laptops, 4K TVs, headphones, cameras, wearables, gaming consoles, and accessories).

Built with **Python 3**, **Django 6**, **SQLite**, **Django Authentication**, **Bootstrap 5.3**, **Bootstrap Icons**, and **Vanilla JavaScript / AJAX**.

---

## 🌟 Key Features

### 🛒 Customer & Storefront Features
- **Modern Responsive Homepage**:
  - Hero carousel with call-to-action slides and modern animations.
  - "Why Choose Us" service assurance highlights (Free delivery over $99, 100% Genuine, 2-Year Warranty, 24/7 Tech Support).
  - Visual category showcase cards with product counts.
  - Featured products grid with discount badges, star ratings, and quick actions.
  - Special Offers promotion section & latest arrivals.
  - Top authorized brand partners grid & newsletter subscription.
- **Product Catalog & Advanced Filtering (`/products/`)**:
  - Global search querying product names, brands, categories, descriptions, and technical specifications.
  - Sidebar multi-filters: Category, Brand, Price Range (Min/Max), and In-stock only filter.
  - Multi-criteria sorting: *Latest Arrivals*, *Price: Low to High*, *Price: High to Low*, *Name: A to Z*, *Name: Z to A*, *Biggest Discount*.
  - Bootstrap pagination preserving active filter queries.
  - Live result counter ("Showing X of Y products found").
- **Product Detail Page (`/products/<slug>/`)**:
  - High-resolution interactive image gallery with thumbnail switcher.
  - Dynamic pricing with discount percentages and instant savings calculations.
  - Live stock indicators (In Stock units count / Out of stock badge).
  - Structured technical specifications table (RAM, Storage, Processor, Display, etc.).
  - AJAX-powered Add to Cart with quantity selection.
  - "Buy Now" button for instant 1-click checkout.
  - Wishlist toggle button.
  - Verified customer reviews list with star rating breakdown and single-review-per-user submission form.
  - Related product recommendations in the same category.
- **Shopping Cart (`/cart/`)**:
  - Real-time stock validation preventing orders exceeding inventory.
  - Quantity increment (`+`), decrement (`-`), and remove controls with dynamic totals.
  - Automatic discount calculations, shipping fee computation (Free over $99), and grand total.
  - Attractive empty cart state with call-to-action button.
- **Wishlist (`/wishlist/`)**:
  - Save favorite electronic items.
  - "Move to Cart" one-click action.
  - Real-time navbar badge counters.
- **Secure Checkout & Mock Online Gateway (`/checkout/`)**:
  - Address selection from saved user addresses or new address entry with automatic saving.
  - Payment methods: **Cash on Delivery (COD)** or **Online Payment Gateway**.
  - Interactive mock payment gateway simulating Credit/Debit Cards, UPI QR codes, and NetBanking with instant sandbox testing.
  - Atomic database transactions creating orders, order items, reducing product stock, and generating unique order numbers (`ORD-YYYYMMDD-XXXXXX`).
  - Order success confirmation page with printable receipt.
- **Order Management (`/orders/`)**:
  - Customer order history with status filter tabs (*Pending*, *Confirmed*, *Processing*, *Shipped*, *Delivered*, *Cancelled*).
  - Detailed order view with visual delivery progress timeline and itemized breakdown.
  - Order cancellation permitted only when order status is *Pending* or *Confirmed* (automatically restores product inventory).
  - Clean printable invoice view (`/orders/<order_number>/invoice/`).
- **User Authentication & Profile (`/accounts/`)**:
  - Registration with first name, last name, username, email, and password validation.
  - Login via username or email address.
  - Profile update and secure password change.
  - Saved shipping address management (Add, Edit, Set Default, Delete).

---

### 🛡️ Admin & Control Center Features
- **Custom Bootstrap Admin Dashboard (`/custom-admin/`)**:
  - Accessible to staff and superusers.
  - Key performance indicator metric cards: *Total Sales Revenue*, *Total Orders*, *Pending Orders*, *Delivered Orders*, *Total Products*, *Total Users*.
  - Visual charts powered by **Chart.js**: Order Status Breakdown and Catalog Distribution.
  - Recent store orders and recent customer review feeds.
- **Product Management (`/custom-admin/products/`)**:
  - Full CRUD: Add product, Edit product, Delete product, Stock adjustments, and Multi-image gallery uploads.
- **Category & Brand Management (`/custom-admin/categories/`, `/custom-admin/brands/`)**:
  - Add, manage, and delete categories and brand partners with image/logo uploads.
- **Order Status & Fulfillment (`/custom-admin/orders/`)**:
  - Change order fulfillment status (*Pending*, *Confirmed*, *Processing*, *Shipped*, *Delivered*, *Cancelled*).
  - Update payment status (*Pending*, *Paid*, *Failed*, *COD*).
- **Reviews Moderation (`/custom-admin/reviews/`)**:
  - Moderate and delete inappropriate customer reviews.
- **Customer Directory (`/custom-admin/users/`)**:
  - View registered customer accounts, order counts, and registration dates.
- **Standard Django Admin (`/admin/`)**:
  - Fully configured with search, filter bars, editable lists, and inline models.

---

## 🛠️ Technology Stack

| Layer | Technology |
|---|---|
| **Backend** | Python 3.10+, Django 5.x/6.x |
| **Database** | SQLite3 (configured with Django ORM) |
| **Frontend** | HTML5, CSS3, JavaScript (ES6+), Bootstrap 5.3, Bootstrap Icons |
| **Image Processing** | Pillow (PIL) |
| **Data Visuals** | Chart.js 4.4 |

---

## 📁 Project Structure

```
d:/Elec/
├── manage.py
├── requirements.txt
├── README.md
├── db.sqlite3
├── electronic_store/
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
├── accounts/
│   ├── models.py          # Address model
│   ├── views.py           # Register, Login, Logout, Profile, Password, Addresses
│   ├── forms.py           # RegistrationForm, LoginForm, ProfileForm, AddressForm
│   ├── urls.py
│   └── tests.py
├── products/
│   ├── models.py          # Category, Brand, Product, ProductImage
│   ├── views.py           # Home, ProductList, ProductDetail, Categories, Search, 404/500
│   ├── urls.py
│   ├── admin.py
│   ├── tests.py
│   └── management/
│       └── commands/
│           └── seed_data.py  # Populates 10 categories, 10 brands, 20 products, reviews, users
├── cart/
│   ├── models.py          # Cart, CartItem
│   ├── views.py           # CartDetail, AddToCart, UpdateQuantity, RemoveItem, ClearCart
│   ├── context_processors.py # Injects live cart_count and wishlist_count globally
│   ├── urls.py
│   └── tests.py
├── wishlist/
│   ├── models.py          # Wishlist model
│   ├── views.py           # WishlistView, AddWishlist, RemoveWishlist, MoveToCart
│   ├── urls.py
│   └── tests.py
├── orders/
│   ├── models.py          # Order, OrderItem
│   ├── views.py           # Checkout, MockOnlinePayment, OrderSuccess, MyOrders, OrderDetail, CancelOrder, Invoice
│   ├── forms.py           # CheckoutForm
│   ├── urls.py
│   └── tests.py
├── reviews/
│   ├── models.py          # Review model (1-5 rating validation)
│   ├── views.py           # SubmitReview, DeleteReview
│   ├── forms.py           # ReviewForm
│   ├── urls.py
│   └── tests.py
├── store_admin/
│   ├── views.py           # Dashboard KPIs, Charts, Product/Category/Brand/Order/Review CRUD
│   ├── forms.py           # AdminProductForm, AdminCategoryForm, AdminBrandForm, AdminOrderStatusForm
│   ├── urls.py
│   └── tests.py
├── static/
│   ├── css/custom.css     # Modern responsive styling, hover effects, card elevation
│   └── js/main.js         # AJAX cart/wishlist handlers, toast alerts, gallery switcher
├── media/                 # Auto-generated product and category images
└── templates/
    ├── base.html
    ├── navbar.html
    ├── footer.html
    ├── messages.html
    ├── 404.html
    ├── 500.html
    ├── accounts/
    ├── products/
    ├── cart/
    ├── wishlist/
    ├── orders/
    └── store_admin/
```

---

## 🚀 Quick Start & Installation

### 1. Prerequisites
Ensure you have **Python 3.10+** installed.

### 2. Set Up Virtual Environment (Recommended)

**On Windows:**
```powershell
python -m venv venv
.\venv\Scripts\activate
```

**On macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Apply Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Seed Sample Data (Categories, Brands, Products, Users)
Run the automated seeder to load 10 categories, 10 brands, 20 realistic electronic products with images, reviews, and test accounts:
```bash
python manage.py seed_data
```

### 6. Run the Development Server
```bash
python manage.py runserver
```

Open your browser and navigate to:
👉 **`http://127.0.0.1:8000/`**

---

## 🔑 Demo Login Credentials

| Role | Username | Password | Access / Permissions |
|---|---|---|---|
| **Super Admin** | `admin` | `admin123` | Store Admin Dashboard (`/custom-admin/`) & Django Admin (`/admin/`) |
| **Customer** | `customer` | `customer123` | Storefront, Cart, Wishlist, Checkout, Order Tracking |

---

## 🧪 Running Automated Tests

Run the complete test suite verifying model calculations, checkout logic, stock controls, and authentication:

```bash
python manage.py test
```

All 13 test suites will run and pass cleanly.

---

## 🌐 Main URLs Reference

| Endpoint | Description |
|---|---|
| `/` | Homepage with carousel, categories, featured and latest tech products |
| `/products/` | Product catalog with filters, search, sorting, and pagination |
| `/products/<slug>/` | Product detail page with specs table and reviews |
| `/categories/` | All categories overview page |
| `/cart/` | Shopping cart with live quantity controls |
| `/wishlist/` | Saved wishlist items |
| `/checkout/` | Shipping address entry and order placement |
| `/orders/` | My Orders history and tracking |
| `/orders/<order_number>/` | Order details with progress bar and cancellation |
| `/orders/<order_number>/invoice/` | Printable order receipt / invoice |
| `/custom-admin/` | Staff Admin Dashboard with charts and analytics |
| `/custom-admin/products/` | Admin product management (Add, Edit, Delete) |
| `/custom-admin/orders/` | Admin order fulfillment and payment status management |
| `/admin/` | Standard Django admin interface |
| `/register/` & `/login/` | User authentication |

---

## 📄 License
This project is developed as an open-source demonstration of an Online Electronic Product Selling System.
