from django.db import models
from django.utils.text import slugify
from decimal import Decimal

class Category(models.Model):
    name = models.CharField(max_length=120, unique=True)
    slug = models.SlugField(max_length=150, unique=True, blank=True)
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to='categories/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Categories'
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    @property
    def icon_class(self):
        slug = (self.slug or '').lower()
        if 'camera' in slug:
            return 'bi-camera-fill'
        elif 'computer' in slug:
            return 'bi-pc-display'
        elif 'game' in slug or 'gaming' in slug:
            return 'bi-controller'
        elif 'headphone' in slug or 'audio' in slug:
            return 'bi-headphones'
        elif 'laptop' in slug:
            return 'bi-laptop'
        elif 'mobile-acc' in slug:
            return 'bi-phone-vibrate'
        elif 'watch' in slug:
            return 'bi-smartwatch'
        elif 'phone' in slug or 'smartphone' in slug:
            return 'bi-phone-fill'
        elif 'speaker' in slug:
            return 'bi-speaker-fill'
        elif 'tv' in slug or 'television' in slug:
            return 'bi-tv'
        return 'bi-tag-fill'

    @property
    def icon_color(self):
        slug = (self.slug or '').lower()
        if 'camera' in slug:
            return '#06b6d4'
        elif 'computer' in slug:
            return '#60a5fa'
        elif 'game' in slug or 'gaming' in slug:
            return '#a855f7'
        elif 'headphone' in slug:
            return '#f43f5e'
        elif 'laptop' in slug:
            return '#3b82f6'
        elif 'mobile-acc' in slug:
            return '#10b981'
        elif 'watch' in slug:
            return '#f59e0b'
        elif 'phone' in slug:
            return '#38bdf8'
        elif 'speaker' in slug:
            return '#ec4899'
        elif 'tv' in slug or 'television' in slug:
            return '#ef4444'
        return '#0d6efd'


class Brand(models.Model):
    name = models.CharField(max_length=120, unique=True)
    slug = models.SlugField(max_length=150, unique=True, blank=True)
    logo = models.ImageField(upload_to='brands/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='products')
    brand = models.ForeignKey(Brand, on_delete=models.CASCADE, related_name='products')
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=280, unique=True, blank=True)
    description = models.TextField()
    specifications = models.TextField(help_text="Enter key: value pairs separated by newlines or format as text")
    price = models.DecimalField(max_digits=10, decimal_places=2)
    discount_percentage = models.PositiveIntegerField(default=0, help_text="Discount in % (0-100)")
    stock = models.PositiveIntegerField(default=10)
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    is_featured = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def save(self, *args, **kwargs):
        if not self.slug:
            base_slug = slugify(self.name)
            slug = base_slug
            counter = 1
            while Product.objects.filter(slug=slug).exclude(pk=self.pk).exists():
                slug = f"{base_slug}-{counter}"
                counter += 1
            self.slug = slug
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

    @property
    def discounted_price(self):
        if self.discount_percentage > 0:
            discount = (self.price * Decimal(self.discount_percentage)) / Decimal(100)
            return round(self.price - discount, 2)
        return self.price

    @property
    def discount_amount(self):
        if self.discount_percentage > 0:
            return round((self.price * Decimal(self.discount_percentage)) / Decimal(100), 2)
        return Decimal('0.00')

    @property
    def in_stock(self):
        return self.stock > 0

    @property
    def average_rating(self):
        reviews = self.reviews.all()
        if reviews.exists():
            total = sum(r.rating for r in reviews)
            return round(total / reviews.count(), 1)
        return 0.0

    @property
    def review_count(self):
        return self.reviews.count()

    @property
    def parsed_specifications(self):
        """Parses line-separated key: value strings into list of dicts"""
        specs = []
        if not self.specifications:
            return specs
        for line in self.specifications.splitlines():
            line = line.strip()
            if not line:
                continue
            if ':' in line:
                key, val = line.split(':', 1)
                specs.append({'key': key.strip(), 'value': val.strip()})
            else:
                specs.append({'key': 'Feature', 'value': line})
        return specs


class ProductImage(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='additional_images')
    image = models.ImageField(upload_to='products/gallery/')

    def __str__(self):
        return f"Image for {self.product.name}"
