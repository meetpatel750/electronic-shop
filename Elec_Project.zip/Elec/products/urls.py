from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('products/', views.product_list_view, name='product_list'),
    path('products/<slug:slug>/', views.product_detail_view, name='product_detail'),
    path('category/<slug:category_slug>/', views.product_list_view, name='category_products'),
    path('categories/', views.category_list_view, name='category_list'),
    path('search/', views.product_list_view, name='search'),
    path('about/', views.about_view, name='about'),
    path('contact/', views.contact_view, name='contact'),
]
