from django.test import TestCase, Client
from django.urls import reverse
from decimal import Decimal
from products.models import Category, Brand, Product
from reviews.models import Review
from django.contrib.auth.models import User

class ProductModelAndViewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.category = Category.objects.create(name='Smartphones', description='Phones')
        self.brand = Brand.objects.create(name='Apple')
        self.product = Product.objects.create(
            category=self.category,
            brand=self.brand,
            name='Test iPhone 15',
            description='Test description',
            specifications='RAM: 8GB\nStorage: 128GB',
            price=Decimal('1000.00'),
            discount_percentage=10,
            stock=5,
            is_featured=True,
            is_active=True
        )

    def test_product_calculations(self):
        self.assertEqual(self.product.discounted_price, Decimal('900.00'))
        self.assertEqual(self.product.discount_amount, Decimal('100.00'))
        self.assertTrue(self.product.in_stock)

    def test_home_view(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test iPhone 15')

    def test_product_list_and_search(self):
        response = self.client.get(reverse('product_list'), {'search': 'iPhone'})
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test iPhone 15')

        # Negative search
        response_neg = self.client.get(reverse('product_list'), {'search': 'NonExistentXYZ'})
        self.assertEqual(response_neg.status_code, 200)
        self.assertContains(response_neg, 'No Products Found')

    def test_product_detail_view(self):
        response = self.client.get(reverse('product_detail', kwargs={'slug': self.product.slug}))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Hardware & Specifications')
        self.assertContains(response, 'RAM')
