from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from django.db.models import Q, Count
from .models import Category, Brand, Product, ProductImage
from reviews.models import Review
from reviews.forms import ReviewForm

def home_view(request):
    banner_products = Product.objects.filter(is_featured=True, is_active=True).select_related('category', 'brand').order_by('id')[:5]
    if not banner_products.exists():
        banner_products = Product.objects.filter(is_active=True).select_related('category', 'brand')[:5]
    featured_products = Product.objects.filter(is_featured=True, is_active=True)[:8]
    latest_products = Product.objects.filter(is_active=True).order_by('-created_at')[:8]
    special_offers = Product.objects.filter(is_active=True, discount_percentage__gte=10).order_by('-discount_percentage')[:8]
    categories = Category.objects.annotate(product_count=Count('products')).filter(product_count__gt=0)[:10]
    if not categories.exists():
        categories = Category.objects.all()[:10]
    brands = Brand.objects.all()[:12]

    context = {
        'banner_products': banner_products,
        'featured_products': featured_products,
        'latest_products': latest_products,
        'special_offers': special_offers,
        'categories': categories,
        'brands': brands,
    }
    return render(request, 'products/home.html', context)


def product_list_view(request, category_slug=None):
    queryset = Product.objects.filter(is_active=True).select_related('category', 'brand')

    # Search Query
    search_query = request.GET.get('search', '').strip()
    if search_query:
        queryset = queryset.filter(
            Q(name__icontains=search_query) |
            Q(brand__name__icontains=search_query) |
            Q(category__name__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(specifications__icontains=search_query)
        )

    # Category Filter (from param or query string)
    cat_param = category_slug or request.GET.get('category', '').strip()
    selected_category = None
    if cat_param:
        if str(cat_param).isdigit():
            queryset = queryset.filter(category__id=int(cat_param))
            selected_category = Category.objects.filter(id=int(cat_param)).first()
        else:
            queryset = queryset.filter(category__slug=cat_param)
            selected_category = Category.objects.filter(slug=cat_param).first()

    # Brand Filter
    brand_slug = request.GET.get('brand', '').strip()
    selected_brand = None
    if brand_slug:
        if brand_slug.isdigit():
            queryset = queryset.filter(brand__id=int(brand_slug))
            selected_brand = Brand.objects.filter(id=int(brand_slug)).first()
        else:
            queryset = queryset.filter(brand__slug=brand_slug)
            selected_brand = Brand.objects.filter(slug=brand_slug).first()

    # Price Filters
    min_price = request.GET.get('min_price', '').strip()
    if min_price and min_price.isdigit():
        queryset = queryset.filter(price__gte=float(min_price))

    max_price = request.GET.get('max_price', '').strip()
    if max_price and max_price.isdigit():
        queryset = queryset.filter(price__lte=float(max_price))

    # In-stock only
    in_stock = request.GET.get('in_stock', '').strip()
    if in_stock == '1':
        queryset = queryset.filter(stock__gt=0)

    # Sorting
    sort = request.GET.get('sort', 'latest')
    if sort == 'price_low':
        queryset = queryset.order_by('price')
    elif sort == 'price_high':
        queryset = queryset.order_by('-price')
    elif sort == 'name_asc':
        queryset = queryset.order_by('name')
    elif sort == 'name_desc':
        queryset = queryset.order_by('-name')
    elif sort == 'discount':
        queryset = queryset.order_by('-discount_percentage')
    else:  # 'latest'
        queryset = queryset.order_by('-created_at')

    total_count = queryset.count()

    # Pagination (9 per page)
    paginator = Paginator(queryset, 9)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # Filters context
    all_categories = Category.objects.annotate(product_count=Count('products')).all()
    all_brands = Brand.objects.annotate(product_count=Count('products')).all()

    # Build query string without 'page' for clean pagination links
    get_copy = request.GET.copy()
    if 'page' in get_copy:
        get_copy.pop('page')
    query_string = get_copy.urlencode()

    context = {
        'products': page_obj,
        'page_obj': page_obj,
        'total_count': total_count,
        'search_query': search_query,
        'selected_category': selected_category,
        'selected_brand': selected_brand,
        'selected_category_param': category_slug,
        'selected_brand_param': brand_slug,
        'min_price': min_price,
        'max_price': max_price,
        'in_stock': in_stock,
        'sort': sort,
        'categories': all_categories,
        'brands': all_brands,
        'query_string': query_string,
    }
    return render(request, 'products/product_list.html', context)


def product_detail_view(request, slug):
    product = get_object_or_404(Product.objects.select_related('category', 'brand'), slug=slug, is_active=True)
    additional_images = product.additional_images.all()
    reviews = product.reviews.select_related('user').order_by('-created_at')
    
    # Check if user already reviewed
    user_review = None
    if request.user.is_authenticated:
        user_review = reviews.filter(user=request.user).first()

    review_form = ReviewForm() if not user_review else None

    # Related products in same category
    related_products = Product.objects.filter(
        category=product.category,
        is_active=True
    ).exclude(pk=product.pk)[:4]

    context = {
        'product': product,
        'additional_images': additional_images,
        'reviews': reviews,
        'user_review': user_review,
        'review_form': review_form,
        'related_products': related_products,
    }
    return render(request, 'products/product_detail.html', context)


def category_list_view(request):
    categories = Category.objects.annotate(product_count=Count('products')).all()
    return render(request, 'products/category_list.html', {'categories': categories})


def about_view(request):
    return render(request, 'products/about.html')


def contact_view(request):
    if request.method == 'POST':
        from django.contrib import messages
        name = request.POST.get('name', '').strip()
        email = request.POST.get('email', '').strip()
        subject = request.POST.get('subject', '').strip()
        message = request.POST.get('message', '').strip()

        if name and email and message:
            messages.success(request, f"Thank you, {name}! Your message has been sent successfully. Our support team will reply to {email} within 24 hours.")
            return render(request, 'products/contact.html', {'submitted': True})
        else:
            messages.error(request, "Please fill in all required fields.")

    return render(request, 'products/contact.html')


def custom_404_view(request, exception=None):
    return render(request, '404.html', status=404)


def custom_500_view(request):
    return render(request, '500.html', status=500)

