import os
from decimal import Decimal
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.conf import settings
from products.models import Category, Brand, Product, ProductImage
from accounts.models import Address
from reviews.models import Review
from cart.models import Cart
from orders.models import Order, OrderItem
from PIL import Image, ImageDraw, ImageFont

def generate_placeholder_image(filename, text, size=(600, 600), bg_color=(33, 37, 41), text_color=(255, 255, 255), subtext=None):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    img = Image.new('RGB', size, color=bg_color)
    draw = ImageDraw.Draw(img)

    # Draw rounded rectangle / border inside
    draw.rectangle([(15, 15), (size[0] - 15, size[1] - 15)], outline=(255, 255, 255, 60), width=3)
    draw.rectangle([(30, 30), (size[0] - 30, size[1] - 30)], fill=(bg_color[0] + 15, bg_color[1] + 15, bg_color[2] + 15))

    # Center text box
    draw.text((size[0] // 2, size[1] // 2 - 20), text, fill=text_color, anchor="mm")
    if subtext:
        draw.text((size[0] // 2, size[1] // 2 + 25), subtext, fill=(200, 200, 200), anchor="mm")

    img.save(filename, 'PNG')
    return filename


class Command(BaseCommand):
    help = 'Seeds database with categories, brands, realistic electronic products, demo users and reviews'

    def handle(self, *args, **options):
        self.stdout.write(self.style.NOTICE("Seeding database for ElectroShop..."))

        # 1. Superuser
        admin_user, created = User.objects.get_or_create(
            username='admin',
            defaults={
                'email': 'admin@electroshop.com',
                'first_name': 'Super',
                'last_name': 'Admin',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        if created:
            admin_user.set_password('admin123')
            admin_user.save()
            self.stdout.write(self.style.SUCCESS("Superuser created: admin / admin123"))
        else:
            admin_user.set_password('admin123')
            admin_user.is_staff = True
            admin_user.is_superuser = True
            admin_user.save()

        # 2. Demo Customer
        customer, created = User.objects.get_or_create(
            username='customer',
            defaults={
                'email': 'customer@example.com',
                'first_name': 'Alex',
                'last_name': 'Johnson',
            }
        )
        if created:
            customer.set_password('customer123')
            customer.save()
            Cart.objects.get_or_create(user=customer)
            self.stdout.write(self.style.SUCCESS("Customer user created: customer / customer123"))
        else:
            customer.set_password('customer123')
            customer.save()

        # Sample Reviewer User
        reviewer, _ = User.objects.get_or_create(
            username='tech_geek',
            defaults={
                'email': 'geek@example.com',
                'first_name': 'Sarah',
                'last_name': 'Miller',
            }
        )
        reviewer.set_password('customer123')
        reviewer.save()

        # 3. Customer Address
        Address.objects.get_or_create(
            user=customer,
            full_name='Alex Johnson',
            defaults={
                'phone': '+1 (555) 234-5678',
                'address_line': '742 Evergreen Terrace, Apt 4B',
                'city': 'Springfield',
                'state': 'Oregon',
                'pincode': '97477',
                'country': 'United States',
                'is_default': True
            }
        )

        # 4. Categories
        categories_data = [
            ("Smartphones", "Next-generation smartphones with stunning cameras, 5G and OLED displays.", (26, 35, 126)),
            ("Laptops", "High-performance laptops for creators, programmers, and gamers.", (38, 50, 56)),
            ("Televisions", "Ultra HD 4K & 8K Smart OLED/QLED TVs for cinema-grade entertainment.", (27, 94, 32)),
            ("Headphones", "Noise-cancelling over-ear headphones and true wireless earbuds.", (191, 54, 12)),
            ("Cameras", "Mirrorless and DSLR digital cameras for photography enthusiasts.", (74, 20, 140)),
            ("Smart Watches", "Fitness trackers, GPS smartwatches, and stylish health monitors.", (0, 77, 64)),
            ("Speakers", "Portable waterproof Bluetooth speakers and premium home soundbars.", (136, 14, 79)),
            ("Gaming", "Next-gen consoles, mechanical gaming controllers, and gear.", (224, 0, 50)),
            ("Computer Accessories", "Keyboards, high-DPI ergonomic mice, monitors, and docks.", (69, 90, 100)),
            ("Mobile Accessories", "Fast power banks, wireless chargers, GaN adapters, and cables.", (230, 81, 0)),
        ]

        cat_objs = {}
        for name, desc, color in categories_data:
            img_rel_path = f"categories/{name.lower().replace(' ', '_')}.png"
            img_abs_path = os.path.join(settings.MEDIA_ROOT, img_rel_path)
            generate_placeholder_image(img_abs_path, name, size=(400, 300), bg_color=color, subtext="ElectroShop Category")

            cat, _ = Category.objects.get_or_create(
                name=name,
                defaults={
                    'description': desc,
                    'image': img_rel_path
                }
            )
            cat_objs[name] = cat

        # 5. Brands
        brands_data = [
            ("Apple", (17, 17, 17)),
            ("Samsung", (10, 40, 100)),
            ("Sony", (0, 0, 0)),
            ("Dell", (0, 118, 206)),
            ("HP", (0, 150, 214)),
            ("ASUS", (30, 30, 30)),
            ("JBL", (255, 85, 0)),
            ("Canon", (204, 0, 0)),
            ("Logitech", (0, 184, 222)),
            ("Xiaomi", (255, 103, 0)),
        ]

        brand_objs = {}
        for name, color in brands_data:
            img_rel_path = f"brands/{name.lower().replace(' ', '_')}.png"
            img_abs_path = os.path.join(settings.MEDIA_ROOT, img_rel_path)
            generate_placeholder_image(img_abs_path, name, size=(300, 150), bg_color=color, subtext="Official Brand")

            b, _ = Brand.objects.get_or_create(
                name=name,
                defaults={'logo': img_rel_path}
            )
            brand_objs[name] = b

        # 6. Realistic Products
        products_data = [
            {
                "name": "Apple iPhone 15 Pro Max",
                "category": "Smartphones",
                "brand": "Apple",
                "price": Decimal("1199.00"),
                "discount": 5,
                "stock": 25,
                "is_featured": True,
                "description": "Forged in titanium and featuring the groundbreaking A17 Pro chip, customizable Action button, and the most powerful iPhone camera system ever.",
                "specs": "Processor: Apple A17 Pro (3nm)\nDisplay: 6.7-inch Super Retina XDR OLED (120Hz)\nMain Camera: 48MP + 12MP + 12MP (5x Optical Zoom)\nStorage: 256GB NVMe\nBattery: 4422 mAh Fast Charging\nOS: iOS 17 (Upgradable)",
                "color": (25, 25, 30)
            },
            {
                "name": "Samsung Galaxy S24 Ultra",
                "category": "Smartphones",
                "brand": "Samsung",
                "price": Decimal("1299.99"),
                "discount": 10,
                "stock": 18,
                "is_featured": True,
                "description": "Meet Galaxy S24 Ultra, the ultimate form of Galaxy Ultra with a new titanium exterior and a 6.8-inch flat display. Packed with Galaxy AI.",
                "specs": "Processor: Snapdragon 8 Gen 3 for Galaxy\nDisplay: 6.8-inch Dynamic AMOLED 2X, 120Hz, 2600 nits\nMain Camera: 200MP Quad Tele System\nStorage: 512GB UFS 4.0\nBattery: 5000 mAh with 45W Fast Charging\nStylus: Built-in S-Pen",
                "color": (20, 35, 60)
            },
            {
                "name": "Apple MacBook Pro 16 M3 Max",
                "category": "Laptops",
                "brand": "Apple",
                "price": Decimal("3499.00"),
                "discount": 8,
                "stock": 12,
                "is_featured": True,
                "description": "The most advanced chips ever built for a personal computer. Up to 22 hours of battery life and a stunning Liquid Retina XDR display.",
                "specs": "Processor: Apple M3 Max (16-core CPU, 40-core GPU)\nMemory: 36GB Unified Memory\nStorage: 1TB PCIe NVMe SSD\nDisplay: 16.2-inch Liquid Retina XDR (3456x2234, 120Hz ProMotion)\nBattery: 100Wh (Up to 22 hrs)\nPorts: 3x Thunderbolt 4, HDMI, SDXC, MagSafe 3",
                "color": (40, 40, 45)
            },
            {
                "name": "Dell XPS 15 9530 OLED",
                "category": "Laptops",
                "brand": "Dell",
                "price": Decimal("2199.00"),
                "discount": 15,
                "stock": 15,
                "is_featured": True,
                "description": "Immerse yourself in content with a breathtaking 3.5K OLED touchscreen display, Intel Core i9-13900H processor, and NVIDIA GeForce RTX 4070 graphics.",
                "specs": "Processor: Intel Core i9-13900H (14-Core, up to 5.4 GHz)\nGraphics: NVIDIA GeForce RTX 4070 (8GB GDDR6)\nMemory: 32GB DDR5 4800MHz\nStorage: 1TB M.2 PCIe NVMe SSD\nDisplay: 15.6-inch 3.5K (3456x2160) OLED Touch\nWeight: 1.92 kg",
                "color": (0, 70, 130)
            },
            {
                "name": "Sony WH-1000XM5 Wireless Headphones",
                "category": "Headphones",
                "brand": "Sony",
                "price": Decimal("399.99"),
                "discount": 20,
                "stock": 30,
                "is_featured": True,
                "description": "Industry-leading noise canceling with two processors and 8 microphones. Magnificent audio engineered to perfection with High-Resolution Audio support.",
                "specs": "Driver: 30mm Precision Engineered Driver\nNoise Cancellation: Dual Processor V1 & QN1 with 8 Mics\nBattery Life: Up to 30 Hours (40 Hours with NC Off)\nConnectivity: Bluetooth 5.2, Multipoint, LDAC, 3.5mm AUX\nMicrophone: 4 Beamforming Mics with AI Noise Reduction",
                "color": (20, 20, 20)
            },
            {
                "name": "Sony Bravia XR 65-inch 4K OLED TV",
                "category": "Televisions",
                "brand": "Sony",
                "price": Decimal("1999.00"),
                "discount": 12,
                "stock": 8,
                "is_featured": True,
                "description": "Pure black and intense color on an OLED screen powered by the revolutionary Cognitive Processor XR. Acoustic Surface Audio+ sound from the entire screen.",
                "specs": "Screen Size: 65 Inch (164 cm)\nPanel: 4K OLED (3840 x 2160) 120Hz\nProcessor: Cognitive Processor XR\nHDR: Dolby Vision, HDR10, HLG\nAudio: 50W Acoustic Surface Audio+ (Dolby Atmos)\nSmart OS: Google TV with Chromecast built-in",
                "color": (15, 25, 35)
            },
            {
                "name": "Canon EOS R6 Mark II Mirrorless Camera",
                "category": "Cameras",
                "brand": "Canon",
                "price": Decimal("2499.00"),
                "discount": 10,
                "stock": 9,
                "is_featured": True,
                "description": "Blistering speed and class-leading video performance. 24.2 MP full-frame CMOS sensor, 40 fps electronic shutter, 4K 60p 10-bit internal video.",
                "specs": "Sensor: 24.2MP Full-Frame CMOS\nVideo: 4K 60p 10-bit Canon Log 3 & HDR PQ\nContinuous Shooting: Up to 40 fps Electronic / 12 fps Mechanical\nAutofocus: Dual Pixel CMOS AF II with Deep Learning Tracking\nStabilization: 5-Axis In-Body Image Stabilization (up to 8 stops)",
                "color": (180, 0, 0)
            },
            {
                "name": "Apple Watch Ultra 2 GPS + Cellular",
                "category": "Smart Watches",
                "brand": "Apple",
                "price": Decimal("799.00"),
                "discount": 0,
                "stock": 20,
                "is_featured": True,
                "description": "The ultimate sports and adventure watch. Robust 49mm titanium case, precision dual-frequency GPS, up to 36 hours battery life, and ultra-bright 3000-nit display.",
                "specs": "Case: 49mm Aerospace Titanium Case\nDisplay: Always-On Retina LTPO OLED (3000 nits peak)\nProcessor: S9 SiP with 64-bit dual-core\nWater Resistance: 100m (EN13319 certified for diving to 40m)\nBattery: Up to 36 hours normal, up to 72 hours low power\nConnectivity: LTE, UMTS, Wi-Fi 4, Bluetooth 5.3, UWB",
                "color": (60, 60, 65)
            },
            {
                "name": "JBL Boombox 3 Portable Bluetooth Speaker",
                "category": "Speakers",
                "brand": "JBL",
                "price": Decimal("499.95"),
                "discount": 15,
                "stock": 22,
                "is_featured": False,
                "description": "Massive sound and deepest bass. 3-way speaker system delivering high sensitivity and crisp clarity. IP67 dust and waterproof with 24 hours of playtime.",
                "specs": "Output Power: 1x 80W RMS Subwoofer + 2x 40W RMS Midrange + 2x 10W RMS Tweeter\nFrequency Response: 40 Hz - 20k Hz\nBattery Life: Up to 24 Hours (10,000 mAh Li-ion)\nWaterproof Rating: IP67 Waterproof & Dustproof\nFeatures: JBL Original Pro Sound, PartyBoost pairing, Built-in Powerbank",
                "color": (220, 80, 0)
            },
            {
                "name": "Sony PlayStation 5 Slim Console",
                "category": "Gaming",
                "brand": "Sony",
                "price": Decimal("499.99"),
                "discount": 5,
                "stock": 35,
                "is_featured": True,
                "description": "Experience lightning-fast loading with an ultra-high speed 1TB SSD, deeper immersion with haptic feedback, adaptive triggers, and 3D Audio.",
                "specs": "CPU: x86-64-AMD Ryzen Zen 2 (8 Cores / 16 Threads)\nGPU: AMD Radeon RDNA 2-based graphics (10.3 TFLOPs)\nStorage: 1TB Custom NVMe SSD\nOutput: 4K 120Hz TVs, 8K TVs, VRR support\nIncludes: DualSense Wireless Controller, Astro's Playroom pre-installed",
                "color": (20, 30, 80)
            },
            {
                "name": "Logitech MX Master 3S Wireless Mouse",
                "category": "Computer Accessories",
                "brand": "Logitech",
                "price": Decimal("99.99"),
                "discount": 10,
                "stock": 50,
                "is_featured": False,
                "description": "An icon remastered. Quiet Clicks and 8,000 DPI track-on-glass sensor. MagSpeed electromagnetic scrolling for ultimate precision and speed.",
                "specs": "Sensor: 8,000 DPI Darkfield High Precision (tracks on glass)\nButtons: 7 Buttons (Left/Right, Back/Forward, App-Switch, Wheel mode, Middle)\nScroll Wheel: MagSpeed Smartshift with ultra-quiet clicks\nBattery: Rechargeable Li-Po (500 mAh) up to 70 days\nConnectivity: Bluetooth Low Energy & Logi Bolt USB",
                "color": (0, 150, 180)
            },
            {
                "name": "Logitech G915 LIGHTSPEED Wireless Mechanical Keyboard",
                "category": "Computer Accessories",
                "brand": "Logitech",
                "price": Decimal("249.99"),
                "discount": 18,
                "stock": 25,
                "is_featured": False,
                "description": "A breakthrough in design and engineering. Low profile GL mechanical switches and pro-grade 1ms LIGHTSPEED wireless with full LIGHTSYNC RGB.",
                "specs": "Switches: GL Tactile Low Profile Mechanical Switches\nActuation Distance: 1.5 mm (45g force)\nBattery Life: 30 hours (100% RGB brightness)\nConnectivity: LIGHTSPEED Wireless + Bluetooth\nMaterial: Aircraft-grade 5052 aluminum alloy top case",
                "color": (50, 50, 60)
            },
            {
                "name": "Xiaomi 65W GaN Fast Charger Trio",
                "category": "Mobile Accessories",
                "brand": "Xiaomi",
                "price": Decimal("39.99"),
                "discount": 25,
                "stock": 100,
                "is_featured": False,
                "description": "Ultra-compact Gallium Nitride (GaN) fast charger capable of charging laptops, tablets, and phones simultaneously with dynamic power distribution.",
                "specs": "Total Output: 65W Max\nPorts: 2x USB-C + 1x USB-A\nFast Charging Protocols: PD 3.0, QC 4.0+, PPS, AFC, FCP\nSafety Protections: Over-voltage, Over-current, Short-circuit, Temperature control\nDimensions: 34 x 30 x 79 mm (Ultra compact)",
                "color": (220, 90, 0)
            },
            {
                "name": "Xiaomi 20000mAh 50W Power Bank",
                "category": "Mobile Accessories",
                "brand": "Xiaomi",
                "price": Decimal("49.99"),
                "discount": 15,
                "stock": 60,
                "is_featured": False,
                "description": "Charges laptops with 50W MAX Type-C fast charging. Triple-port output charges three devices at once. High-quality lithium-ion polymer battery.",
                "specs": "Capacity: 20,000 mAh (74Wh)\nInput: Type-C (Up to 45W)\nOutput: Type-C (50W MAX), USB-A (22.5W MAX)\nCompatibility: MacBooks, ThinkPads, Nintendo Switch, iPhones, Androids\nWeight: 440g",
                "color": (30, 30, 35)
            },
            {
                "name": "ASUS ROG Swift 27-inch 360Hz Gaming Monitor",
                "category": "Gaming",
                "brand": "ASUS",
                "price": Decimal("699.00"),
                "discount": 14,
                "stock": 14,
                "is_featured": True,
                "description": "World's fastest 1440p Esports gaming monitor. Ultrafast 360Hz refresh rate, 0.03ms response time OLED panel with NVIDIA G-SYNC compatibility.",
                "specs": "Panel: 27-inch QHD (2560 x 1440) Fast IPS / OLED\nRefresh Rate: 360Hz\nResponse Time: 0.03ms (GTG)\nColor Gamut: 99% DCI-P3, HDR10\nSync Technology: NVIDIA G-SYNC & AMD FreeSync Premium Pro",
                "color": (150, 0, 40)
            },
            {
                "name": "HP Spectre x360 2-in-1 Laptop 14-inch",
                "category": "Laptops",
                "brand": "HP",
                "price": Decimal("1649.99"),
                "discount": 12,
                "stock": 16,
                "is_featured": False,
                "description": "Crafted from recycled aluminum, this 2-in-1 PC combines artistic gem-cut design with AI-enhanced performance and a vibrant 2.8K OLED touch display.",
                "specs": "Processor: Intel Core Ultra 7 155H with Intel AI Boost NPU\nDisplay: 14-inch 2.8K (2880 x 1800) OLED 120Hz Touch\nMemory: 32GB LPDDR5x RAM\nStorage: 1TB PCIe Gen4 NVMe\nIncludes: HP Rechargeable MPP2.0 Tilt Pen & Sleeve",
                "color": (0, 110, 160)
            },
            {
                "name": "Samsung 55-inch The Frame QLED 4K TV",
                "category": "Televisions",
                "brand": "Samsung",
                "price": Decimal("1497.99"),
                "discount": 10,
                "stock": 10,
                "is_featured": False,
                "description": "Artwork, television, movies, and memories - The Frame showcases them all on a beautiful Matte Display. Modern bezel design hangs flush against the wall.",
                "specs": "Display: 55-inch 4K QLED Matte Display (Anti-Reflection)\nRefresh Rate: 120Hz (Motion Xcelerator 120Hz)\nArt Mode: Displays museum-quality art and personal photos\nMount: Slim Fit Wall Mount included in box\nProcessor: Quantum Processor 4K",
                "color": (30, 60, 110)
            },
            {
                "name": "JBL Live Pro 2 True Wireless Earbuds",
                "category": "Headphones",
                "brand": "JBL",
                "price": Decimal("149.95"),
                "discount": 20,
                "stock": 40,
                "is_featured": False,
                "description": "True Adaptive Noise Cancelling with Smart Ambient. Up to 40 hours of JBL Signature Sound, 6 beamforming microphones for crystal-clear calls, and IPX5 water resistance.",
                "specs": "Driver: 11mm Dynamic Drivers\nBattery Life: 10 hrs in earbuds + 30 hrs in Qi Wireless Charging Case\nNoise Cancelling: True Adaptive Noise Cancelling\nMicrophones: 6 Beamforming Mics with VoiceAware\nWater Resistance: IPX5 Splashproof",
                "color": (240, 100, 20)
            },
            {
                "name": "Dell UltraSharp 32-inch 4K USB-C Hub Monitor",
                "category": "Computer Accessories",
                "brand": "Dell",
                "price": Decimal("829.99"),
                "discount": 10,
                "stock": 15,
                "is_featured": False,
                "description": "Brilliant visuals and contrast with IPS Black technology. Comprehensive connectivity with 90W power delivery USB-C, RJ45 Ethernet, and Daisy Chain support.",
                "specs": "Size: 31.5-inch 4K UHD (3840 x 2160) at 60Hz\nPanel: IPS Black Technology (2000:1 Contrast Ratio)\nColor: 100% sRGB, 98% DCI-P3, Delta E < 2\nHub Ports: USB-C (90W Power), RJ45 Ethernet, DisplayPort 1.4, HDMI 2.0, USB 3.2 Gen 2\nStand: Height-adjustable, tilt, swivel, pivot",
                "color": (0, 90, 160)
            },
            {
                "name": "Apple AirPods Pro 2nd Gen USB-C",
                "category": "Headphones",
                "brand": "Apple",
                "price": Decimal("249.00"),
                "discount": 12,
                "stock": 45,
                "is_featured": True,
                "description": "Featuring the Apple H2 chip, Pro-level Active Noise Cancellation, Adaptive Audio, Transparency mode, and Personalized Spatial Audio with dynamic head tracking.",
                "specs": "Chip: Apple H2 Headphone chip & U1 in MagSafe Case\nAudio Tech: Custom high-excursion driver & high dynamic range amplifier\nNoise Cancellation: Up to 2x more Active Noise Cancellation\nBattery: Up to 6 hours listening (30 hours with case)\nCase: MagSafe Charging Case (USB-C) with Speaker and Lanyard loop",
                "color": (240, 240, 240)
            }
        ]

        created_products = []
        for p in products_data:
            img_rel_path = f"products/{p['name'].lower().replace(' ', '_').replace('/', '_')}.png"
            img_abs_path = os.path.join(settings.MEDIA_ROOT, img_rel_path)
            generate_placeholder_image(
                img_abs_path,
                p['name'],
                size=(600, 600),
                bg_color=p['color'],
                text_color=(255, 255, 255) if p['color'] != (240, 240, 240) else (30, 30, 30),
                subtext=f"{p['brand']} | {p['category']}"
            )

            prod, _ = Product.objects.get_or_create(
                name=p['name'],
                defaults={
                    'category': cat_objs[p['category']],
                    'brand': brand_objs[p['brand']],
                    'price': p['price'],
                    'discount_percentage': p['discount'],
                    'stock': p['stock'],
                    'is_featured': p['is_featured'],
                    'is_active': True,
                    'description': p['description'],
                    'specifications': p['specs'],
                    'image': img_rel_path,
                }
            )
            created_products.append(prod)

            # Generate 2 gallery images for each product
            for i in [1, 2]:
                gal_rel_path = f"products/gallery/{prod.slug}_view_{i}.png"
                gal_abs_path = os.path.join(settings.MEDIA_ROOT, gal_rel_path)
                generate_placeholder_image(
                    gal_abs_path,
                    f"{prod.name} (Angle {i})",
                    size=(600, 600),
                    bg_color=p['color'],
                    text_color=(255, 255, 255) if p['color'] != (240, 240, 240) else (30, 30, 30),
                    subtext="Product Detail Shot"
                )
                ProductImage.objects.get_or_create(
                    product=prod,
                    image=gal_rel_path
                )

        # 7. Sample Reviews
        sample_reviews = [
            (5, "Absolutely top tier! Performance is unbelievable and battery easily lasts 2 full days. Highly recommended!"),
            (5, "Exceptional build quality and premium finish. Best purchase I've made this year."),
            (4, "Great electronics device with super crisp display. Fast delivery by ElectroShop!"),
            (5, "Exceeded all my expectations. Smooth software experience and solid hardware."),
            (4, "Very satisfied with the product performance. Value for money on discount."),
        ]

        for i, prod in enumerate(created_products[:10]):
            r_user = reviewer if i % 2 == 0 else customer
            rating, comment = sample_reviews[i % len(sample_reviews)]
            Review.objects.get_or_create(
                user=r_user,
                product=prod,
                defaults={
                    'rating': rating,
                    'comment': comment
                }
            )

        # 8. Sample Past Order for Customer
        if not Order.objects.filter(user=customer).exists():
            p1 = created_products[0]
            p2 = created_products[4]
            sub = p1.discounted_price + (p2.discounted_price * 2)
            disc = p1.discount_amount + (p2.discount_amount * 2)
            
            sample_order = Order.objects.create(
                user=customer,
                address=Address.objects.filter(user=customer).first(),
                shipping_address_text="Alex Johnson, Phone: +1 (555) 234-5678, 742 Evergreen Terrace, Apt 4B, Springfield, Oregon - 97477, United States",
                subtotal=sub + disc,
                discount=disc,
                shipping_charge=Decimal('0.00'),
                total_amount=sub,
                payment_method="Online Payment",
                payment_status="Paid",
                order_status="Delivered"
            )

            OrderItem.objects.create(
                order=sample_order,
                product=p1,
                product_name=p1.name,
                price=p1.discounted_price,
                quantity=1,
                total=p1.discounted_price
            )
            OrderItem.objects.create(
                order=sample_order,
                product=p2,
                product_name=p2.name,
                price=p2.discounted_price,
                quantity=2,
                total=p2.discounted_price * 2
            )

        self.stdout.write(self.style.SUCCESS("Successfully seeded ElectroShop sample data!"))
