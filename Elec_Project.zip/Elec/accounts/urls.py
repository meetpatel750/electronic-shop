from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('profile/change-password/', views.change_password_view, name='change_password'),
    path('change-password/', views.change_password_view, name='change_password_alias'),
    path('profile/addresses/', views.address_list_view, name='address_list'),
    path('profile/addresses/add/', views.add_address_view, name='add_address'),
    path('profile/addresses/<int:pk>/edit/', views.edit_address_view, name='edit_address'),
    path('profile/addresses/<int:pk>/delete/', views.delete_address_view, name='delete_address'),
    path('profile/addresses/<int:pk>/default/', views.set_default_address_view, name='set_default_address'),
]
