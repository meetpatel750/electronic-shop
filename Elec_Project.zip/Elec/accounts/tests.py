from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from accounts.models import Address

class AccountsTest(TestCase):
    def setUp(self):
        self.client = Client()

    def test_registration_valid(self):
        response = self.client.post(reverse('register'), {
            'first_name': 'John',
            'last_name': 'Doe',
            'username': 'johndoe',
            'email': 'john@example.com',
            'mobile_number': '9876543210',
            'password': 'password123',
            'confirm_password': 'password123',
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(User.objects.filter(username='johndoe').exists())

    def test_registration_invalid_password_mismatch(self):
        response = self.client.post(reverse('register'), {
            'first_name': 'John',
            'last_name': 'Doe',
            'username': 'johndoe_mismatch',
            'email': 'john2@example.com',
            'password': 'password123',
            'confirm_password': 'password999',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Passwords do not match')

    def test_registration_invalid_name_and_username(self):
        response = self.client.post(reverse('register'), {
            'first_name': 'John123',
            'last_name': 'Doe!',
            'username': 'jo hn with space',
            'email': 'invalid-email',
            'password': '123',
            'confirm_password': '123',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'First name should only contain letters')
        self.assertContains(response, 'Username can only contain letters')

    def test_login_and_profile(self):
        user = User.objects.create_user(username='tester', email='tester@example.com', password='password123')
        
        # Login
        response = self.client.post(reverse('login'), {
            'username': 'tester',
            'password': 'password123'
        })
        self.assertEqual(response.status_code, 302)

        # Profile
        response_profile = self.client.get(reverse('profile'))
        self.assertEqual(response_profile.status_code, 200)
        self.assertContains(response_profile, 'tester')

    def test_login_invalid_credentials(self):
        response = self.client.post(reverse('login'), {
            'username': 'non_existent_user',
            'password': 'wrongpassword'
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Invalid username/email or password')

    def test_address_management(self):
        user = User.objects.create_user(username='addr_user', password='password123')
        self.client.login(username='addr_user', password='password123')

        response = self.client.post(reverse('add_address'), {
            'full_name': 'Jane Doe',
            'phone': '1234567890',
            'address_line': '123 Main St',
            'city': 'New York',
            'state': 'NY',
            'pincode': '10001',
            'country': 'United States',
            'is_default': True
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Address.objects.filter(user=user, city='New York').exists())
