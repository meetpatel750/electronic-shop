import re
from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import PasswordChangeForm
from .models import Address, UserProfile

class RegistrationForm(forms.ModelForm):
    first_name = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. John', 'id': 'id_first_name'})
    )
    last_name = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Doe', 'id': 'id_last_name'})
    )
    username = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. johndoe', 'id': 'id_username'})
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'e.g. john@example.com', 'id': 'id_email'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Min. 6 characters', 'id': 'reg_password'}),
        min_length=6
    )
    confirm_password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Re-enter password', 'id': 'reg_confirm_password'}),
        min_length=6
    )
    mobile_number = forms.CharField(
        max_length=10,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'e.g. 9876543210',
            'id': 'id_mobile',
            'inputmode': 'numeric',
            'maxlength': '10',
        })
    )

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'email']

    def clean_first_name(self):
        first_name = self.cleaned_data.get('first_name', '').strip()
        if len(first_name) < 2:
            raise forms.ValidationError("First name must contain at least 2 characters.")
        if not re.match(r"^[a-zA-Z\s\-']+$", first_name):
            raise forms.ValidationError("First name should only contain letters.")
        return first_name.title()

    def clean_last_name(self):
        last_name = self.cleaned_data.get('last_name', '').strip()
        if len(last_name) < 2:
            raise forms.ValidationError("Last name must contain at least 2 characters.")
        if not re.match(r"^[a-zA-Z\s\-']+$", last_name):
            raise forms.ValidationError("Last name should only contain letters.")
        return last_name.title()

    def clean_username(self):
        username = self.cleaned_data.get('username', '').strip().lower()
        if len(username) < 3:
            raise forms.ValidationError("Username must be at least 3 characters long.")
        if not re.match(r"^[a-zA-Z0-9_]+$", username):
            raise forms.ValidationError("Username can only contain letters, numbers, and underscores (no spaces or special characters).")
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("This username is already taken. Please choose another.")
        return username

    def clean_email(self):
        email = self.cleaned_data.get('email', '').strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email address already exists. Please log in.")
        return email

    def clean_mobile_number(self):
        mobile = self.cleaned_data.get('mobile_number', '').strip()
        if not mobile.isdigit():
            raise forms.ValidationError("Mobile number must contain digits only (no spaces or dashes).")
        if len(mobile) < 10:
            raise forms.ValidationError(f"Mobile number is too short. Please enter exactly 10 digits (entered {len(mobile)}).")
        if len(mobile) > 10:
            raise forms.ValidationError(f"Mobile number is too long. Please enter exactly 10 digits (entered {len(mobile)}).")
        if mobile[0] == '0':
            raise forms.ValidationError("Mobile number should not start with 0.")
        return mobile

    def clean_password(self):
        password = self.cleaned_data.get('password', '')
        if len(password) < 6:
            raise forms.ValidationError("Password must be at least 6 characters long.")
        if password.isdigit():
            raise forms.ValidationError("Password cannot be entirely numeric. Please include letters.")
        return password

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password and confirm_password and password != confirm_password:
            self.add_error('confirm_password', "Passwords do not match. Please re-enter identical passwords.")
        return cleaned_data


class LoginForm(forms.Form):
    username = forms.CharField(
        required=True,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username or Email', 'id': 'login_username'})
    )
    password = forms.CharField(
        required=True,
        widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password', 'id': 'login_password'})
    )

    def clean_username(self):
        return self.cleaned_data.get('username', '').strip()


class ProfileForm(forms.ModelForm):
    first_name = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First Name'}))
    last_name = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last Name'}))
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email Address'}))
    mobile_number = forms.CharField(
        max_length=10,
        required=False,
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '10-digit mobile number', 'maxlength': '10', 'inputmode': 'numeric'})
    )

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            profile = getattr(self.instance, 'profile', None)
            if profile:
                self.fields['mobile_number'].initial = profile.mobile_number

    def clean_first_name(self):
        first_name = self.cleaned_data.get('first_name', '').strip()
        if len(first_name) < 2:
            raise forms.ValidationError("First name must be at least 2 characters.")
        if not re.match(r"^[a-zA-Z\s\-']+$", first_name):
            raise forms.ValidationError("First name should only contain letters.")
        return first_name.title()

    def clean_last_name(self):
        last_name = self.cleaned_data.get('last_name', '').strip()
        if len(last_name) < 2:
            raise forms.ValidationError("Last name must be at least 2 characters.")
        if not re.match(r"^[a-zA-Z\s\-']+$", last_name):
            raise forms.ValidationError("Last name should only contain letters.")
        return last_name.title()

    def clean_mobile_number(self):
        mobile = self.cleaned_data.get('mobile_number', '').strip()
        if mobile:
            if not mobile.isdigit():
                raise forms.ValidationError("Mobile number must contain digits only.")
            if len(mobile) != 10:
                raise forms.ValidationError(f"Mobile number must be exactly 10 digits (currently {len(mobile)} digits).")
            if mobile[0] == '0':
                raise forms.ValidationError("Mobile number should not start with 0.")
        return mobile

    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit:
            mobile = self.cleaned_data.get('mobile_number', '')
            profile, _ = UserProfile.objects.get_or_create(user=user)
            profile.mobile_number = mobile
            profile.save()
        return user


class CustomPasswordChangeForm(PasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs['class'] = 'form-control'


class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = ['full_name', 'phone', 'address_line', 'city', 'state', 'pincode', 'country', 'is_default']
        widgets = {
            'full_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Full Name'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '10-digit Mobile Number'}),
            'address_line': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Street Address, Flat / House No., Area'}),
            'city': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'City'}),
            'state': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'State / Province'}),
            'pincode': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Postal / Zip Code'}),
            'country': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Country'}),
            'is_default': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }
