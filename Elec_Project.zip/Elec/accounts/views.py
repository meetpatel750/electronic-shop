from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import RegistrationForm, LoginForm, ProfileForm, CustomPasswordChangeForm, AddressForm
from .models import Address, UserProfile
from cart.models import Cart

def register_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            # Save mobile number in UserProfile
            mobile = form.cleaned_data.get('mobile_number', '')
            UserProfile.objects.create(user=user, mobile_number=mobile)
            # Create user cart automatically
            Cart.objects.get_or_create(user=user)
            messages.success(request, f"Welcome to ElectroShop, {user.first_name or user.username}! Your account has been created successfully. Please sign in below to start exploring.")
            return redirect('login')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = RegistrationForm()

    return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    next_url = request.GET.get('next', 'home')
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username_or_email = form.cleaned_data['username']
            password = form.cleaned_data['password']

            # Allow login via username or email
            user = None
            if '@' in username_or_email:
                user_obj = User.objects.filter(email=username_or_email).first()
                if user_obj:
                    user = authenticate(request, username=user_obj.username, password=password)
            else:
                user = authenticate(request, username=username_or_email, password=password)

            if user is not None:
                if user.is_active:
                    login(request, user)
                    Cart.objects.get_or_create(user=user)
                    messages.success(request, f"Welcome back, {user.first_name or user.username}!")
                    return redirect(request.POST.get('next') or next_url)
                else:
                    messages.error(request, "This account is inactive.")
            else:
                messages.error(request, "Invalid username/email or password.")
    else:
        form = LoginForm()

    return render(request, 'accounts/login.html', {'form': form, 'next': next_url})


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('home')


@login_required
def profile_view(request):
    user = request.user
    if request.method == 'POST':
        form = ProfileForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "Your profile details have been updated successfully!")
            return redirect('profile')
        else:
            messages.error(request, "Failed to update profile. Please correct the errors below.")
    else:
        form = ProfileForm(instance=user)

    addresses = Address.objects.filter(user=user)
    default_address = addresses.filter(is_default=True).first() or addresses.first()
    recent_orders = user.orders.all().order_by('-created_at')[:5]
    total_orders_count = user.orders.count()
    pending_orders_count = user.orders.filter(order_status__in=['Pending', 'Confirmed', 'Processing', 'Shipped']).count()
    wishlist_count = user.wishlist.items.count() if hasattr(user, 'wishlist') else 0

    return render(request, 'accounts/profile.html', {
        'form': form,
        'addresses': addresses,
        'default_address': default_address,
        'recent_orders': recent_orders,
        'total_orders_count': total_orders_count,
        'pending_orders_count': pending_orders_count,
        'wishlist_count': wishlist_count,
    })


@login_required
def change_password_view(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, "Your password has been changed successfully!")
            return redirect('profile')
        else:
            messages.error(request, "Please correct the error below.")
    else:
        form = CustomPasswordChangeForm(user=request.user)

    return render(request, 'accounts/change_password.html', {'form': form})


@login_required
def address_list_view(request):
    addresses = Address.objects.filter(user=request.user)
    return render(request, 'accounts/addresses.html', {'addresses': addresses})


@login_required
def add_address_view(request):
    next_url = request.GET.get('next', 'address_list')
    if request.method == 'POST':
        form = AddressForm(request.POST)
        if form.is_valid():
            address = form.save(commit=False)
            address.user = request.user
            # If this is the user's first address, make it default
            if not Address.objects.filter(user=request.user).exists():
                address.is_default = True
            address.save()
            messages.success(request, "Address saved successfully.")
            return redirect(request.POST.get('next') or next_url)
        else:
            messages.error(request, "Please correct the address details.")
    else:
        form = AddressForm()

    return render(request, 'accounts/address_form.html', {'form': form, 'title': 'Add New Address', 'next': next_url})


@login_required
def edit_address_view(request, pk):
    address = get_object_or_404(Address, pk=pk, user=request.user)
    next_url = request.GET.get('next', 'address_list')

    if request.method == 'POST':
        form = AddressForm(request.POST, instance=address)
        if form.is_valid():
            form.save()
            messages.success(request, "Address updated successfully.")
            return redirect(request.POST.get('next') or next_url)
        else:
            messages.error(request, "Please check the form inputs.")
    else:
        form = AddressForm(instance=address)

    return render(request, 'accounts/address_form.html', {'form': form, 'title': 'Edit Address', 'next': next_url})


@login_required
def delete_address_view(request, pk):
    address = get_object_or_404(Address, pk=pk, user=request.user)
    if request.method == 'POST':
        address.delete()
        messages.success(request, "Address removed successfully.")
    return redirect('address_list')


@login_required
def set_default_address_view(request, pk):
    address = get_object_or_404(Address, pk=pk, user=request.user)
    Address.objects.filter(user=request.user).update(is_default=False)
    address.is_default = True
    address.save()
    messages.success(request, f"'{address.full_name}' address set as default.")
    return redirect('address_list')
