from django.contrib import admin
from .models import Address

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ('user', 'full_name', 'phone', 'city', 'state', 'pincode', 'is_default', 'created_at')
    list_filter = ('is_default', 'city', 'state', 'country')
    search_fields = ('user__username', 'full_name', 'phone', 'city', 'pincode')
