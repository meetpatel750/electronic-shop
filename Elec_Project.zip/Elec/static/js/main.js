// ElectroShop Main JavaScript

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

// Toast Notification Helper
function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        container.style.zIndex = '1100';
        document.body.appendChild(container);
    }

    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success text-white' : (type === 'error' || type === 'danger' ? 'bg-danger text-white' : 'bg-primary text-white');
    const iconClass = type === 'success' ? 'bi-check-circle-fill' : 'bi-info-circle-fill';

    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center ${bgClass} border-0 shadow-lg" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body d-flex align-items-center">
                    <i class="bi ${iconClass} me-2 fs-5"></i>
                    <div>${message}</div>
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;

    container.insertAdjacentHTML('beforeend', toastHtml);
    const toastElem = document.getElementById(toastId);
    const bsToast = new bootstrap.Toast(toastElem, { delay: 3500 });
    bsToast.show();

    toastElem.addEventListener('hidden.bs.toast', () => {
        toastElem.remove();
    });
}

// Update Cart and Wishlist Badges
function updateCounters(cartCount, wishlistCount) {
    if (cartCount !== undefined) {
        const cartBadges = document.querySelectorAll('.cart-count-badge');
        cartBadges.forEach(b => {
            b.textContent = cartCount;
            b.style.display = cartCount > 0 ? 'inline-block' : 'none';
        });
    }
    if (wishlistCount !== undefined) {
        const wishBadges = document.querySelectorAll('.wishlist-count-badge');
        wishBadges.forEach(b => {
            b.textContent = wishlistCount;
            b.style.display = wishlistCount > 0 ? 'inline-block' : 'none';
        });
    }
}

// AJAX Add to Cart
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.ajax-add-to-cart');
    if (!btn) return;

    e.preventDefault();
    const productId = btn.dataset.productId;
    const qtyInput = document.getElementById('product-quantity-input');
    const quantity = qtyInput ? qtyInput.value : (btn.dataset.quantity || 1);

    const formData = new FormData();
    formData.append('quantity', quantity);

    fetch(`/cart/add/${productId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(res => {
        if (res.redirected) {
            window.location.href = res.url;
            return;
        }
        return res.json();
    })
    .then(data => {
        if (data) {
            if (data.status === 'success') {
                showToast(data.message, 'success');
                updateCounters(data.cart_count, undefined);
            } else {
                showToast(data.message, 'danger');
            }
        }
    })
    .catch(err => {
        console.error("Cart error:", err);
    });
});

// AJAX Wishlist Toggle
document.addEventListener('click', function(e) {
    const btn = e.target.closest('.ajax-wishlist-toggle');
    if (!btn) return;

    e.preventDefault();
    const productId = btn.dataset.productId;
    const formData = new FormData();
    formData.append('toggle', '1');

    fetch(`/wishlist/add/${productId}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': csrftoken,
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: formData
    })
    .then(res => {
        if (res.redirected) {
            window.location.href = res.url;
            return;
        }
        return res.json();
    })
    .then(data => {
        if (data) {
            showToast(data.message, data.status === 'added' ? 'success' : 'info');
            updateCounters(undefined, data.wishlist_count);
            
            const icon = btn.querySelector('i');
            if (icon) {
                if (data.status === 'added') {
                    icon.classList.remove('bi-heart');
                    icon.classList.add('bi-heart-fill', 'text-danger');
                    btn.classList.add('active');
                } else if (data.status === 'removed') {
                    icon.classList.remove('bi-heart-fill', 'text-danger');
                    icon.classList.add('bi-heart');
                    btn.classList.remove('active');
                }
            }
        }
    })
    .catch(err => console.error("Wishlist error:", err));
});

// Gallery Image Switcher on Product Detail Page
document.addEventListener('DOMContentLoaded', function() {
    const mainImg = document.getElementById('main-product-image');
    const thumbs = document.querySelectorAll('.thumb-img');

    if (mainImg && thumbs.length > 0) {
        thumbs.forEach(thumb => {
            thumb.addEventListener('click', function() {
                thumbs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                mainImg.src = this.src;
            });
        });
    }

    // Checkout Address Selector switch
    const addressSelect = document.getElementById('saved-address-select');
    const newAddressSection = document.getElementById('new-address-section');

    if (addressSelect && newAddressSection) {
        function toggleNewAddress() {
            if (addressSelect.value) {
                newAddressSection.style.display = 'none';
            } else {
                newAddressSection.style.display = 'block';
            }
        }
        addressSelect.addEventListener('change', toggleNewAddress);
        toggleNewAddress();
    }
});
