from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal
from products.models import Category, Brand, Product
from wishlist.models import Wishlist
from cart.models import Cart

class WishlistTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='wish_user', password='password123')
        self.client.login(username='wish_user', password='password123')

        self.category = Category.objects.create(name='Wearables')
        self.brand = Brand.objects.create(name='Apple')
        self.product = Product.objects.create(
            category=self.category,
            brand=self.brand,
            name='Apple Watch',
            description='Smartwatch',
            specifications='Display: OLED',
            price=Decimal('399.00'),
            stock=5
        )

    def test_add_and_remove_wishlist(self):
        # Add to wishlist
        response = self.client.post(reverse('add_to_wishlist', kwargs={'product_id': self.product.id}))
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Wishlist.objects.filter(user=self.user, product=self.product).exists())

        # Move to cart
        response_move = self.client.get(reverse('move_to_cart', kwargs={'product_id': self.product.id}))
        self.assertEqual(response_move.status_code, 302)
        self.assertFalse(Wishlist.objects.filter(user=self.user, product=self.product).exists())
        
        cart = Cart.objects.get(user=self.user)
        self.assertTrue(cart.items.filter(product=self.product).exists())
