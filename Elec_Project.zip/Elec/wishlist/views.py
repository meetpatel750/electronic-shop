from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from products.models import Product
from cart.models import Cart, CartItem
from .models import Wishlist

@login_required
def wishlist_view(request):
    wishlist_items = Wishlist.objects.filter(user=request.user).select_related('product', 'product__brand', 'product__category')
    return render(request, 'wishlist/wishlist_view.html', {'wishlist_items': wishlist_items})


@login_required
def add_to_wishlist_view(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_active=True)
    is_ajax = request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json'

    item, created = Wishlist.objects.get_or_create(user=request.user, product=product)
    
    if created:
        msg = f"'{product.name}' was added to your wishlist!"
        status = 'added'
        messages.success(request, msg)
    else:
        # If already exists and called via toggle, remove it
        if request.POST.get('toggle') == '1':
            item.delete()
            msg = f"'{product.name}' was removed from your wishlist."
            status = 'removed'
            messages.info(request, msg)
        else:
            msg = f"'{product.name}' is already in your wishlist."
            status = 'exists'
            messages.info(request, msg)

    wishlist_count = Wishlist.objects.filter(user=request.user).count()

    if is_ajax:
        return JsonResponse({
            'status': status,
            'message': msg,
            'wishlist_count': wishlist_count,
            'product_name': product.name,
        })

    return redirect(request.META.get('HTTP_REFERER', 'wishlist_view'))


@login_required
def remove_from_wishlist_view(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    Wishlist.objects.filter(user=request.user, product=product).delete()
    
    msg = f"'{product.name}' removed from your wishlist."
    messages.info(request, msg)

    if request.headers.get('x-requested-with') == 'XMLHttpRequest' or request.GET.get('format') == 'json':
        wishlist_count = Wishlist.objects.filter(user=request.user).count()
        return JsonResponse({
            'status': 'success',
            'message': msg,
            'wishlist_count': wishlist_count,
        })

    return redirect('wishlist_view')


@login_required
def move_to_cart_view(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_active=True)

    if product.stock <= 0:
        messages.error(request, f"Sorry, '{product.name}' is out of stock.")
        return redirect('wishlist_view')

    # Remove from wishlist
    Wishlist.objects.filter(user=request.user, product=product).delete()

    # Add to cart
    cart, _ = Cart.objects.get_or_create(user=request.user)
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if not created:
        if cart_item.quantity < product.stock:
            cart_item.quantity += 1
            cart_item.save()
    else:
        cart_item.quantity = 1
        cart_item.save()

    messages.success(request, f"Moved '{product.name}' to your cart.")
    return redirect('cart_detail')
