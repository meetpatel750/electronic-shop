from django.urls import path
from . import views

urlpatterns = [
    path('', views.wishlist_view, name='wishlist_view'),
    path('add/<int:product_id>/', views.add_to_wishlist_view, name='add_to_wishlist'),
    path('remove/<int:product_id>/', views.remove_from_wishlist_view, name='remove_from_wishlist'),
    path('move-to-cart/<int:product_id>/', views.move_to_cart_view, name='move_to_cart'),
]
