"""
URL configuration for electronic_store project.
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # Legacy alias
    path('custom-admin/', include('store_admin.urls')),

    # Primary Custom Bootstrap Admin Dashboard on /admin/
    path('admin/', include('store_admin.urls')),
    
    # Default Django Backend Admin on /django-admin/
    path('django-admin/', admin.site.urls),

    # Storefront Apps
    path('', include('products.urls')),
    path('', include('accounts.urls')),
    path('cart/', include('cart.urls')),
    path('wishlist/', include('wishlist.urls')),
    path('', include('orders.urls')),
    path('reviews/', include('reviews.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

handler404 = 'products.views.custom_404_view'
handler500 = 'products.views.custom_500_view'
