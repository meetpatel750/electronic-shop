from django.urls import path
from . import views

urlpatterns = [
    path('submit/<int:product_id>/', views.submit_review_view, name='submit_review'),
    path('delete/<int:review_id>/', views.delete_review_view, name='delete_review'),
]
