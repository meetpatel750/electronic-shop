from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from products.models import Product
from .models import Review
from .forms import ReviewForm

@login_required
def submit_review_view(request, product_id):
    product = get_object_or_404(Product, id=product_id, is_active=True)

    if request.method == 'POST':
        # Check if review already exists
        existing_review = Review.objects.filter(user=request.user, product=product).first()
        
        if existing_review:
            form = ReviewForm(request.POST, instance=existing_review)
            if form.is_valid():
                form.save()
                messages.success(request, "Your review has been updated!")
            else:
                messages.error(request, "Error updating review. Please check inputs.")
        else:
            form = ReviewForm(request.POST)
            if form.is_valid():
                review = form.save(commit=False)
                review.user = request.user
                review.product = product
                review.save()
                messages.success(request, "Thank you! Your review has been published.")
            else:
                messages.error(request, "Error submitting review. Please check inputs.")

    return redirect('product_detail', slug=product.slug)


@login_required
def delete_review_view(request, review_id):
    review = get_object_or_404(Review, id=review_id)
    product_slug = review.product.slug

    # Allow author or staff to delete
    if request.user == review.user or request.user.is_staff:
        review.delete()
        messages.success(request, "Review deleted successfully.")
    else:
        messages.error(request, "You do not have permission to delete this review.")

    return redirect(request.META.get('HTTP_REFERER', 'home'))
