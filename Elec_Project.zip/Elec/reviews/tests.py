from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from decimal import Decimal
from products.models import Category, Brand, Product
from reviews.models import Review

class ReviewsTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='reviewer_user', password='password123')
        self.client.login(username='reviewer_user', password='password123')

        self.category = Category.objects.create(name='Cameras')
        self.brand = Brand.objects.create(name='Canon')
        self.product = Product.objects.create(
            category=self.category,
            brand=self.brand,
            name='Canon EOS R6',
            description='Mirrorless camera',
            specifications='Sensor: Full Frame',
            price=Decimal('2000.00'),
            stock=4
        )

    def test_review_submission_and_average(self):
        response = self.client.post(reverse('submit_review', kwargs={'product_id': self.product.id}), {
            'rating': 5,
            'comment': 'Best camera ever!'
        })
        self.assertEqual(response.status_code, 302)

        review = Review.objects.get(user=self.user, product=self.product)
        self.assertEqual(review.rating, 5)
        self.assertEqual(self.product.average_rating, 5.0)
        self.assertEqual(self.product.review_count, 1)
