from django import forms
from .models import Review

class ReviewForm(forms.ModelForm):
    RATING_CHOICES = [
        (5, '★★★★★ (5 Stars - Excellent)'),
        (4, '★★★★☆ (4 Stars - Very Good)'),
        (3, '★★★☆☆ (3 Stars - Average)'),
        (2, '★★☆☆☆ (2 Stars - Poor)'),
        (1, '★☆☆☆☆ (1 Star - Terrible)'),
    ]

    rating = forms.ChoiceField(
        choices=RATING_CHOICES,
        widget=forms.Select(attrs={'class': 'form-select'}),
        initial=5
    )
    comment = forms.CharField(
        widget=forms.Textarea(attrs={
            'class': 'form-control',
            'rows': 4,
            'placeholder': 'Share your experience with this electronic product...'
        })
    )

    class Meta:
        model = Review
        fields = ['rating', 'comment']
